package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CuraAppointmentPom {
	public static WebDriver driver;
	
	public CuraAppointmentPom(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//div[@class='col-sm-4'])[1]/select/option[2]")
	WebElement Facility;
	@FindBy(xpath = "(//div[@class='col-sm-offset-5 col-sm-4'])[1]/label/input")
	WebElement readmissionCheckbox;
	@FindBy(xpath = "(//div[@class='col-sm-4'])[2]/label[2]/input")
	WebElement healthcareProgram;
	@FindBy(xpath = "(//div[@class='col-sm-4'])[3]/div/input")
	WebElement visitDate;
	@FindBy(xpath = "(//div[@class='col-sm-4'])[4]/textarea")
	WebElement comments;
	@FindBy(xpath = "(//div[@class='col-sm-offset-5 col-sm-4'])[2]/button")
	WebElement bookAppointmentButton;
	@FindBy(xpath = "//div[@class='col-xs-12 text-center']/h2")
	WebElement verifyAppointment;
	
	public void selectFacility()
	{
		Facility.click();
	}
	public void confirmCheckbox()
	{
		readmissionCheckbox.click();
	}
	public void selectHealthcareProgram()
	{
		healthcareProgram.click();
	}
	public void inputVisitDate()
	{
		visitDate.sendKeys("05/05/2024");
	}
	public void inputComments()
	{
		comments.sendKeys("nil");
	}
	public void bookAppointment()
	{
		bookAppointmentButton.click();
	}
	public String verifyAppointmentDetails()
	{
		return verifyAppointment.getText();
	}
}

