package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CuraLoginPom {
	public static WebDriver driver;
	
	public CuraLoginPom(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//get menu button
	@FindBy(xpath = "//a[@id='menu-toggle']")
	WebElement menu;
	//get login option
	@FindBy(linkText = "Login")
	WebElement loginPage;
	//get username
	@FindBy(id = "txt-username")
	WebElement username;
	//get password
	@FindBy(id = "txt-password")
	WebElement password;
	//get submit login button
	@FindBy(id = "btn-login")
	WebElement submit;
	//get login failure text
	@FindBy(xpath = "//p[@class='lead text-danger']")
	WebElement failedText;
	
	//click menu button
	public void clickMenuButton() 
	{
		menu.click();
	}
	//navigate to login page
	public void goToLoginPage()
	{
		loginPage.click();
	}
	//enter login credentials
	public void inputLoginCredentials(String uname, String pass)
	{
		username.sendKeys(uname);
		password.sendKeys(pass);
	}
	//click on login button
	public void submitLogin()
	{
		submit.click();
	}
	//get the Login failure message
	public String getLoginFailedMessage()
	{
		return failedText.getText();
	}
}
