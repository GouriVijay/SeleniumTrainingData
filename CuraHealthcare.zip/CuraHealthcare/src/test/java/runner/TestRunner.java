package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
 
@CucumberOptions(
		glue="stepdefinitions",
		features="C:\\Users\\269672\\eclipse-workspace\\CuraHealthcare\\src\\test\\resources\\features"
		)
public class TestRunner extends AbstractTestNGCucumberTests{
	
 
}

 
