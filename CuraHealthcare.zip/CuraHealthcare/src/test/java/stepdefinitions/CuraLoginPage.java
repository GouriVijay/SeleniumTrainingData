package stepdefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.CuraLoginPom;

public class CuraLoginPage {
	
	private final WebDriver driver = Hooks.driver;	
	
	
	@Given("User already open the website into cura healthcare services")
	public void user_already_open_the_website_into_cura_healthcare_services() {
		//check whether the user is at the correct page
	    assertEquals(driver.getCurrentUrl(),"https://katalon-demo-cura.herokuapp.com/");
	}

	@When("User click menu button")
	public void user_click_menu_button() throws InterruptedException {
	    CuraLoginPom login = new CuraLoginPom(driver);
	    login.clickMenuButton();
	    Thread.sleep(1000);
	}

	@When("User navigate to login page")
	public void user_navigate_to_login_page() throws InterruptedException {
		CuraLoginPom login = new CuraLoginPom(driver);
	    login.goToLoginPage();
	    Thread.sleep(2000);
	}

	@When("User input {string} as Username {string} as Password")
	public void user_input_as_username_as_password(String string, String string2) {
		CuraLoginPom login = new CuraLoginPom(driver);
	    login.inputLoginCredentials(string, string2);
	}

	@When("User click on Login button")
	public void user_click_on_login_button() throws InterruptedException {
		CuraLoginPom login = new CuraLoginPom(driver);
	    login.submitLogin();
	    Thread.sleep(2000);
	}

	@Then("User logged in successfully")
	public void user_logged_in_successfully() {
		//ensure successful login by checking if the user is correctly redirected to appointment page
	    assertEquals(driver.getCurrentUrl(),"https://katalon-demo-cura.herokuapp.com/#appointment");
	}

	@Then("Usser get {string} as error message")
	public void usser_get_as_error_message(String string) {
		//verify the error message on login failure
		CuraLoginPom login = new CuraLoginPom(driver);
		assertEquals(string, login.getLoginFailedMessage());
	}


}
