package curahealthcaretest;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import excel.ExcelHandling1;
import base.DriverSetup;
import base.ReusableMethods;
import pom.CuraAppointmentPom;
import pom.CuraLoginPom;
import utilities.TakeScreenshots;
@Listeners(utilities.ExtentReportsListener.class)

public class CuraTest implements ITestListener{
	public static WebDriver driver;
    public static ReusableMethods re;
    public static CuraLoginPom login;
    public static CuraAppointmentPom appointment;
    public static TakeScreenshots ts;
	
	@BeforeClass
	public void setup()
	{
		driver= DriverSetup.invokeChrome();
		re= new ReusableMethods(driver);
		re.openWebsite();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@DataProvider(name = "LoginData")
	public String[][] getLoginData() throws IOException
	{
		String path="C:\\Users\\269672\\eclipse-workspace\\CuraHealthcare\\testdata\\CuraHealthcareData.xlsx";
		String sheet="Sheet1";
		return ExcelHandling1.fetchUserDetails(path, sheet);
	}
	@Test(dataProvider="LoginData")
	public void testSuccessfulAppointmentBooking(String username,String password) throws InterruptedException
	{
		login= new CuraLoginPom(driver);
		login.clickMenuButton();
		Thread.sleep(1000);
		login.goToLoginPage();
		Thread.sleep(2000);
		login.inputLoginCredentials(username,password);
		login.submitLogin();
		Thread.sleep(2000);
		appointment= new CuraAppointmentPom(driver);
		appointment.selectFacility();
		appointment.confirmCheckbox();
		appointment.selectHealthcareProgram();
		appointment.inputVisitDate();
		appointment.inputComments();
		appointment.bookAppointment();
		Thread.sleep(2000);
		assertEquals(appointment.verifyAppointmentDetails(),"Appointment Confirmation");
	}
	@AfterClass
	public void getScreenshots()
	{
		ts = new TakeScreenshots(driver);
	}
}
