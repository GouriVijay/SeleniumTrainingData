package UST.Project1;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.ReusableMethods;
import Excel.ExcelHandling1;
import pom.LoginPom;
import pom.ProductsPom;

@Listeners(UST.Project1.ExtentReportsListener.class)
public class LoginTest implements ITestListener {
	public static WebDriver driver;
	public static ReusableMethods reusableMethods;
	public static LoginPom loginpom;
	public static ProductsPom productspom;
	
	
	
	@BeforeClass(groups= {"valid","invalid","LoginProducts"})
	public void setUp() {
		driver=reusableMethods.invokeBrowser();
		reusableMethods=new ReusableMethods(driver);
		loginpom=new LoginPom(driver);
		productspom=new ProductsPom(driver);
	}
	
	@BeforeMethod(groups= {"valid","invalid","LoginProducts"})
	public void openWebsite() {
		reusableMethods.openWebsite();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@DataProvider(name="testdata1")
	public String[][] getData1() throws IOException{
		String path="C:\\Users\\269657\\eclipse-workspace\\Project1\\LoginData.xlsx";
	    String sheet="Sheet1";
	    return ExcelHandling1.fetchUserDetails(path, sheet);
	}
	
	@Test(dataProvider = "testdata1",groups="valid")
	public void TestValidLogin(String username,String password) {
		loginpom.enterUsername(username);
		loginpom.enterPassword(password);
		loginpom.clickLogin();
		assertEquals("https://www.saucedemo.com/inventory.html",driver.getCurrentUrl());
	}
	
	@DataProvider(name="testdata2")
	public String[][] getData2() throws IOException{
		String path="C:\\Users\\269657\\eclipse-workspace\\Project1\\LoginData.xlsx";
	    String sheet="Sheet2";
	    return ExcelHandling1.fetchUserDetails(path, sheet);
	}
	
	@Test(dataProvider = "testdata2",groups="invalid")
	public void TestInvalidLogin(String username,String password) {
		loginpom.enterUsername(username);
		loginpom.enterPassword(password);
		loginpom.clickLogin();
		assertEquals(true,driver.findElement(By.xpath("//div[@class='error-message-container error']")).isDisplayed());
		assertEquals("https://www.saucedemo.com/",driver.getCurrentUrl());
	}
	
	@Test(groups="invalid")
	public void TestNullLogin() {
		loginpom.clickLogin();
		assertEquals(true,driver.findElement(By.xpath("//div[@class='error-message-container error']")).isDisplayed());
		assertEquals("https://www.saucedemo.com/",driver.getCurrentUrl());
	}
	
//	@AfterMethod(groups = { "add", "remove", "reset" })
//	public void captureScreenshotOfFail(ITestResult result) {
//		if (result.getStatus() == ITestResult.FAILURE) {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			try {
//				FileUtils.copyFile(screenshot, new File("Failedscreenshots/" + ++i + "screenshot.jpg"));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		else {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			try {
//				FileUtils.copyFile(screenshot, new File("Passedscreenshots/" + ++i + "screenshot.jpg"));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}  
	
}

