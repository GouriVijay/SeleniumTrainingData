package UST.Project1;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.ReusableMethods;
import pom.CartPom;
import pom.LoginPom;
import pom.ProductsPom;
@Listeners(UST.Project1.ExtentReportsListener.class)

public class ProductsPageTest implements ITestListener {
	public static WebDriver driver;
	public static ReusableMethods reusableMethods;
	public static ProductsPom productspom;
	public static LoginPom loginPom;
	public static CartPom cartPom;
	
	
   @BeforeClass(groups= {"add","remove","reset"})
   public void setUp() {
	   driver=reusableMethods.invokeBrowser();
		reusableMethods=new ReusableMethods(driver);
		reusableMethods.openWebsite();
		productspom=new ProductsPom(driver);
		loginPom=new LoginPom(driver);
		cartPom=new CartPom(driver);

	}
   
   @BeforeMethod(groups= {"add","remove","reset"})
	public void openWebsite() {
		reusableMethods.openWebsite();
		loginPom.enterUsername("standard_user");
		loginPom.enterPassword("secret_sauce");
		loginPom.clickLogin();
	}
   

   @Test(groups="add",priority=2)
   public void testAddtoCart() throws InterruptedException {
	   productspom.clickFilter();
	   assertEquals(productspom.verifyZtoA(),"Name (Z to A)");
	   productspom.addToCart();
	   assertEquals(cartPom.verifyProduct1(),"Test.allTheThings() T-Shirt (Red)" );
	   assertEquals(cartPom.verifyProduct2(),"Sauce Labs Onesie" );
	   assertEquals(2,cartPom.numberOfItemsInCart());
	
   }
   
   
   @Test(groups="remove",priority=1)
   public void testRemoveFromCart() throws InterruptedException {
	   productspom.clickFilter();
	   productspom.addProduct();
	   cartPom.removeFromCart();
	   assertEquals(0,cartPom.isCartEmpty());
	   driver.navigate().refresh();
	}
   
   
   @Test(groups="reset",priority=3)
   public void testReset(){
	   productspom.clickFilter();
	   productspom.addProduct();
	   cartPom.resetAppState();
	   assertEquals(0,cartPom.numberOfItemsInCart());
//	   driver.navigate().refresh();
   }

//	@AfterMethod(groups = { "add", "remove", "reset" })
//	public void captureScreenshotOfFail(ITestResult result) {
//		if (result.getStatus() == ITestResult.FAILURE) {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			try {
//				FileUtils.copyFile(screenshot, new File("Failedscreenshots/" + ++i + "screenshot.jpg"));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		else {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			try {
//				FileUtils.copyFile(screenshot, new File("Passedscreenshots/" + ++i + "screenshot.jpg"));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}   
   
  
}
