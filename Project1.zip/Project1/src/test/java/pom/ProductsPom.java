package pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductsPom {
	public WebDriver driver;
	
	public ProductsPom(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//select[@class=\"product_sort_container\"]")
	WebElement filter;
	@FindBy(xpath = "//select//option[@value=\"za\"]")
	WebElement za;
	@FindBy(className =  "active_option")
	WebElement checkza;	
	@FindBy(xpath = "(//button[@class=\"btn btn_primary btn_small btn_inventory \"])[1]")
	WebElement addcart1;
	@FindBy(xpath = "(//button[@class=\"btn btn_primary btn_small btn_inventory \"])[1]")
	WebElement addcart2;
	@FindBy(className = "shopping_cart_link")
	WebElement cart;
	
	
	public void clickFilter() {
		filter.click();
		za.click();
	}

	public String verifyZtoA() {
		return checkza.getText();
	}
	
	public void addToCart() {
		addcart1.click();
		addcart2.click();
		cart.click();
	}
	

	public void addProduct() {
		addcart1.click();
		cart.click();
	}
	
	



	
	
	
	
	

}
