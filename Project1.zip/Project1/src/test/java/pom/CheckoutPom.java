package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.yaml.snakeyaml.events.Event.ID;

public class CheckoutPom {
	public WebDriver driver;
	public CheckoutPom(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(id="first-name")
	WebElement first;
	@FindBy(id="last-name")
	WebElement last;
	@FindBy(id="postal-code")
	WebElement post;
	@FindBy(id="continue")
	WebElement next;
	@FindBy(className = "title")	
	WebElement vNext;
	@FindBy(className = "summary_subtotal_label")	
	WebElement item;
	@FindBy(className = "summary_tax_label")	
	WebElement tax;
	@FindBy(className = "summary_total_label")	
	WebElement total;
	@FindBy(id = "finish")
	WebElement finish;
	@FindBy(id = "back-to-products")
	WebElement backHome;
	
	public void enterDetails() {
		first.sendKeys("Gouri");
		last.sendKeys("B");
		post.sendKeys("13570");
		next.click();
	}
	
	public String verifyReceiptPage() {
		return vNext.getText();
	}
	
	public float SumTotal() {
		String i= item.getText();
		String t=tax.getText();
		float i2=Float.parseFloat(i.substring(13));
		float t2=Float.parseFloat(t.substring(6));
		return i2+t2;
		
	}
	
	public float Total() {
		String tp=total.getText();
		Float tp1=Float.parseFloat(tp.substring(8));
		return tp1;
	}
	
	public void clickFinish()
	{
		finish.click();
		backHome.click();
	} 

	
}
