package pom;

import java.util.List;

import org.hamcrest.Factory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPom {
	public WebDriver driver;
	public CartPom(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "(//div[@class=\"inventory_item_name\"])[1]")
	WebElement checkp1;
	@FindBy(xpath = "(//div[@class=\"inventory_item_name\"])[2]")
	WebElement checkp2;
	@FindBy(xpath = "(//button[@class=\"btn btn_secondary btn_small cart_button\"])[1]")
	WebElement removeP1;
	@FindBy(className =  "shopping_cart_badge")
	WebElement checkR1;
	@FindBy(xpath  = "//button[@id='react-burger-menu-btn']")
	WebElement menu;
	@FindBy(linkText = "Reset App State")
	WebElement reset;
	@FindBy(xpath  = "//button[@id='react-burger-cross-btn']")
	WebElement close;
	@FindBy(className = "title")
	WebElement vCart;
	@FindBy(id = "checkout")
	WebElement checkout;
	

	public String verifyProduct1() {
		return checkp1.getText();	
	}
	
	public String verifyProduct2() {
		return checkp2.getText();	
	}
	
	
	public void removeFromCart() {
		removeP1.click();
	}
	
	public WebElement verifyRemoval() {
		return checkR1;	
	}
	
	public void resetAppState() 
	{
		menu.click();
		reset.click();
//		close.click();
	}
		
	public int isCartEmpty() {
		List<WebElement> list = driver.findElements(By.className("shopping_cart_badge"));
		return list.size();
	}
	
	public int numberOfItemsInCart() {
		List<WebElement> list = driver.findElements(By.className("cart_item"));
		return list.size();
	}
	
	public String verifyCart() {
		return vCart.getText();
	}
	
	public void clickCheckout() {
		checkout.click();
	}
	
	
}
