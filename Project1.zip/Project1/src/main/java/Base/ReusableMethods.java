package Base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import Utilities.PropertyFile;
import Base.DriverSetup;

public class ReusableMethods {
	public static WebDriver driver;
	public static Properties properties;
	
	public ReusableMethods(WebDriver driver) {
		this.driver=driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		properties=PropertyFile.getProperties();
	}
	
	public static WebDriver invokeBrowser() {
		if(properties==null) 
			properties=PropertyFile.getProperties();
			String browserChoice=properties.getProperty("browser1");
			try {
			if(browserChoice.equalsIgnoreCase("edge")) {
				driver=DriverSetup.invokeEdge();
			}
			else if (browserChoice.equalsIgnoreCase("chrome")) {
				driver = DriverSetup.invokeChrome();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return driver;
	}
	
	public void openWebsite() {
		driver.get(properties.getProperty("testSiteURL"));
	}
		
		
	
	
	
	

}
