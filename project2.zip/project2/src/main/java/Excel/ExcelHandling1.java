package Excel;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHandling1 {
	
	public static String[][] fetchUserDetails(String path,String sheetName) throws IOException{
	FileInputStream fis=new FileInputStream(path);
	XSSFWorkbook workbook=new XSSFWorkbook(fis);
	XSSFSheet sheet=workbook.getSheet(sheetName);
	int rowCount=sheet.getPhysicalNumberOfRows();
	Row row=sheet.getRow(0);
	int colCount=row.getPhysicalNumberOfCells();
	String[][] data=new String[rowCount][colCount];
	DataFormatter df=new DataFormatter();
	for(int i=0;i<rowCount;i++) {
		for(int j=0;j<colCount;j++) {
			data[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
		}
	}
	
	return data;
	}
}
