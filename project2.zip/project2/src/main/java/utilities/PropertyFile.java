package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyFile {
	private static Properties properties;
	
	public static Properties getProperties() {
		if(properties==null) {
			properties=new Properties();
			FileInputStream fis;
			try {
				fis=new FileInputStream("C:\\Users\\269657\\eclipse-workspace\\project2\\src\\test\\resources\\ObjectRepository\\config.properties");
				properties.load(fis);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return properties;
		
	}
	

}
