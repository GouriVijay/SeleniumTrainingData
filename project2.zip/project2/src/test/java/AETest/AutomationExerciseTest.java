package AETest;
 
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
 
import Excel.ExcelHandling1;
import base.ReusableMethods;
import io.cucumber.java.After;
import pom.AECartPom;
import pom.AECheckoutPom;
import pom.AELoginPom;
import pom.AEProductsPom;
import pom.AESubscriptionPage;
 
public class AutomationExerciseTest {
	   public static WebDriver driver;
	    public static ReusableMethods re;
	    public static AELoginPom login;
	    public static AECartPom cart;
 
	@BeforeClass(groups= {"add","remove","search","checkout","sub"})
	public void setup()
	{
		driver = ReusableMethods.invokeBrower();
		re = new ReusableMethods(driver);
	}
	@BeforeMethod(groups= {"add","remove","search","checkout","sub"})
	public void before()
	{
		re.openWebsite();
	}
	@DataProvider(name="AddToCart")
	public String[][] getAddtoCartData() throws IOException
	{
		String path="C:\\Users\\269657\\eclipse-workspace\\project2\\TestData\\AutomationExerciseData.xlsx";
		String sheet="AddToCart";
		return ExcelHandling1.fetchUserDetails(path, sheet);
	}
	@DataProvider(name="RemoveFromCart")
	public String[][] getRemoveFromCartData() throws IOException
	{
		String path="C:\\Users\\269657\\eclipse-workspace\\project2\\TestData\\AutomationExerciseData.xlsx";
		String sheet="RemoveFromCart";
		return ExcelHandling1.fetchUserDetails(path, sheet);
	}
	@Test(dataProvider="AddToCart",priority=1,groups="add")
	public void testAddToCart(String emailID,String password) throws InterruptedException
	{
		login = new AELoginPom(driver);
		login.clickLoginOption();
		login.enterEmail(emailID);
		login.enterPassword(password);
		login.submitLogin();
        AEProductsPom products = new AEProductsPom(driver);
        cart=new AECartPom(driver);
        Thread.sleep(3000);
		products.goToProducts();
		Thread.sleep(3000);
		products.selectWomenInCategory();
		Thread.sleep(3000);
		products.selectDressForWomen();
		Thread.sleep(3000);
		products.clickViewDress();
		Thread.sleep(3000);
		products.clickAddToCart();
		Thread.sleep(3000);
		products.clickContinueShopping();
		products.clickAllenSollyJunior();
		products.viewAllenSollyJunior();
		products.selectQuantity();
		products.clickAddToCart();
		Thread.sleep(3000);
		products.clickViewCart();
		assertEquals("Rose Pink Embroidered Maxi Dress",cart.maxidress());
		assertEquals("Frozen Tops For Kids",cart.topforkids());
		login.clickLogout();
	}
	@Test(dataProvider="RemoveFromCart",priority=2,groups="remove")
	public void testRemoveFromCart(String emailID,String password) throws InterruptedException
	{
		login = new AELoginPom(driver);
		login.clickLoginOption();
		login.enterEmail(emailID);
		login.enterPassword(password);
		login.submitLogin();
        AEProductsPom products = new AEProductsPom(driver);
        cart= new AECartPom(driver);
        Thread.sleep(3000);
		products.goToProducts();
		Thread.sleep(3000);
		products.selectHandMBrand();
		Thread.sleep(3000);
		products.addHandMProductsToCart();
		Thread.sleep(3000);
		products.clickViewCart();
		cart.removeProductFromCart();
		Thread.sleep(3000);
		cart.removeProductFromCart();
		Thread.sleep(3000);
		cart.goBackToProducts();
		login.clickLogout();
	}
	@Test(dataProvider="RemoveFromCart",priority=3,groups="search")
	public void testProductSearch(String emailID,String password) throws InterruptedException
	{
		login = new AELoginPom(driver);
		login.clickLoginOption();
		login.enterEmail(emailID);
		login.enterPassword(password);
		login.submitLogin();
		AEProductsPom products = new AEProductsPom(driver);
		products.goToProducts();
		products.searchForValidItem();
		assertTrue(products.getNumberOfValidProducts()>0);
		Thread.sleep(2000);
		products.searchForInvalidItem();
		assertTrue(products.getNumberOfInvalidProducts()==0);
		//	Thread.sleep(4000);
		login.clickLogout();
	}
	@Test(dataProvider="RemoveFromCart",priority=4,groups="checkout")
	public void testCheckout(String emailID,String password) throws InterruptedException
	{
		login = new AELoginPom(driver);
		login.clickLoginOption();
		login.enterEmail(emailID);
		login.enterPassword(password);
		login.submitLogin();
		AEProductsPom products = new AEProductsPom(driver);
		cart= new AECartPom(driver);
		AECheckoutPom checkout= new AECheckoutPom(driver);
		Thread.sleep(3000);
		products.goToProducts();
		products.selectWomenInCategory();
		Thread.sleep(3000);
		products.selectDressForWomen();
		Thread.sleep(3000);
		products.clickViewDress();
		Thread.sleep(3000);
		products.clickAddToCart();
		Thread.sleep(1000);
		products.clickViewCart();
		Thread.sleep(1000);
		cart.proceedToCheckout();
		checkout.placeOrder();
		checkout.enterNameOnCard();
		checkout.enterCardNumber();
		checkout.enterCVV();
		checkout.enterMonth();
		checkout.enterYear();
		checkout.clickConfirmBtn();
		Thread.sleep(1000);
		checkout.clickContinueBtn();
		login.clickLogout();
	}
	@Test(priority=5,groups="sub")
	public void testSubscription()
	{
		AESubscriptionPage sub= new AESubscriptionPage(driver);
		sub.enterSubscriptionMail();
		sub.submitMail();
		assertTrue(sub.ifSubscribed());
	}
	@AfterMethod
	public void after() {
		//taking the screenshot after every test
		java.io.File screenshotfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			Date d1 = new Date();
			FileUtils.copyFile(screenshotfile, new File("screenshots/"+ d1.getTime()+ "ss.jpg"));
	} catch (IOException e) {
		e.printStackTrace();
	}
	}
}




