package UST.project2;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.SignupOrLoginPom;
import pom.homePagePom;

public class AELogin {
	//public WebDriver driver=AESignup.driver;
	private final WebDriver driver= Hooks.driver;
	
	@When("User input {string} as emailID {string} as password")
	public void user_input_as_email_id_as_password(String string, String string2) {
	   SignupOrLoginPom login=new SignupOrLoginPom(driver);
	   login.loginEmail(string);
	   login.loginpwd(string2);
	}

	@When("User click login button")
	public void user_click_login_button() {
		SignupOrLoginPom login=new SignupOrLoginPom(driver);
		login.clicklogin();
	}

	@Then("User successfully logged in")
	public void user_successfully_logged_in() {
		homePagePom home=new homePagePom(driver);
		assertEquals(home.verifyLogin(), "Logout");
	}

	@Then("User get {string} as invalid login error message")
	public void user_get_as_invalid_login_error_message(String string) {
		 SignupOrLoginPom login=new SignupOrLoginPom(driver);
		 assertEquals(login.loginError(), "Your email or password is incorrect!");
	}

}
