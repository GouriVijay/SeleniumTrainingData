package UST.project2;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.contactUsPom;
import pom.homePagePom;

public class AEContactUs {
	//public WebDriver driver=AESignup.driver;
	private final WebDriver driver= Hooks.driver;

	@When("User click on contactUs option")
	public void user_click_on_contact_us_option() {
	    homePagePom home=new homePagePom(driver);
	    home.clickContactUs();
	}

	@Then("User verifying contactUs page")
	public void user_verifying_contact_us_page() {
		assertEquals(driver.getCurrentUrl(), "https://automationexercise.com/contact_us");
	}

	@When("User input {string} as name {string} as email {string} as subject {string} as message")
	public void user_input_as_name_as_email_as_subject_as_message(String string, String string2, String string3, String string4) {
		contactUsPom contact=new contactUsPom(driver);
		contact.enterName(string);
		contact.enterEmail(string2);
		contact.enterSubject(string3);
		contact.enterMessage(string4);
	}

	@When("User click submit button")
	public void user_click_submit_button() {
		contactUsPom contact=new contactUsPom(driver);
		contact.clickSubmit();
	}

	@Then("User verify submit is successful")
	public void user_verify_submit_is_successful() {
		contactUsPom contact=new contactUsPom(driver);
		assertEquals(contact.verifySubmit(), "Success! Your details have been submitted successfully.");
	}

	@Then("User go back to home page")
	public void user_go_back_to_home_page() {
		contactUsPom contact=new contactUsPom(driver);
		contact.clickHome();
	}

}
