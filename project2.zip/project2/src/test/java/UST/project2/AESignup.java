package UST.project2;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import base.ReusableMethods;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.SignupOrLoginPom;
import pom.SignupPom;
import pom.homePagePom;

public class AESignup {
	private final WebDriver driver= Hooks.driver;
//	public static ReusableMethods reusableMethods;

   @Given("User already open the website Automation Exercise")
   public void user_already_open_the_website_automation_exercise() {
//	   driver=reusableMethods.invokeBrower();
//		reusableMethods=new ReusableMethods(driver);
//		reusableMethods.openWebsite();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
   }

   @When("User click on SignupOrLogin option")
   public void user_click_on_signup_or_login_option() {
	 homePagePom home=new homePagePom(driver);
	 home.clickSignupOrLogin();
     assertEquals(driver.getCurrentUrl(),"https://automationexercise.com/login");
   }

   @When("User input {string} as name {string} as email address")
   public void user_input_as_name_as_email_address(String string, String string2) {
	   SignupOrLoginPom sl=new SignupOrLoginPom(driver);
	   SignupPom signup=new SignupPom(driver);
		sl.clickName(string);
		sl.clickEmail(string2);
		sl.clickSignup();
   }

   @Then("User is on Signup page")
   public void user_is_on_signup_page() {
	   assertEquals(driver.getCurrentUrl(), "https://automationexercise.com/signup");
   }

   @When("User entering account information and input {string} as password")
   public void user_entering_account_information_and_input_as_password(String string) {
	   SignupPom signup=new SignupPom(driver);
	   signup.clickTitle();
	   signup.EnterPwd(string);
	   signup.clickDob();
	   signup.clickCheckBox();
   }

   @When("User input {string} as firstname {string} as lastname {string} as number")
   public void user_input_as_firstname_as_lastname_as_number(String string, String string2, String string3) {
	   SignupPom signup=new SignupPom(driver);
	   signup.AddressInfo1(string, string2, string3);
   }

   @When("User input {string} as company {string} as address {string} as state {string} as city {string} as zip")
   public void user_input_as_company_as_address_as_state_as_city_as_zip(String string, String string2, String string3, String string4, String string5) {
	   SignupPom signup=new SignupPom(driver);
	   signup.AddressInfo2(string, string2, string3, string4, string5);
   }

   @When("User clicking on create account")
   public void user_clicking_on_create_account() {
	   SignupPom signup=new SignupPom(driver);
	   signup.createAccount();
   }

   @Then("User verifying account created is displayed")
   public void user_verifying_account_created_is_displayed() {
	   SignupPom signup=new SignupPom(driver);
       assertEquals(signup.verifyCreation(),"ACCOUNT CREATED!" );
      
   }

   @Then("User clicking continue")
   public void user_clicking_continue() {
	   SignupPom signup=new SignupPom(driver);
	   signup.clickContinue();
	   signup.deleteAccount();
   }
   
   @Then("User get {string} as error message")
   public void user_get_as_error_message(String string) {
	   SignupPom signup=new SignupPom(driver);
	   assertEquals(signup.errorMessage(), "Email Address already exist!");
   }

}
