package pom;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
 
public class AECartPom {
	public static WebDriver driver;
 
    public AECartPom(WebDriver driver){
    	this.driver = driver;
    	PageFactory.initElements(driver, this); 
    }
    @FindBy(xpath = "(//div[@id='cart_info']/table/tbody/tr/td[6]/a)[1]")
    WebElement removeProduct;
    @FindBy(xpath = "//div[@id='cart_info']/span/p/a")
    WebElement backToProducts;
    @FindBy(xpath = "//a[@class='btn btn-default check_out']")
	WebElement ProceedtocChkOutButton;
    @FindBy(xpath="//span//p[@class=\"text-center\"]//b")
    WebElement verifyRemove;
    @FindBy(linkText = "Rose Pink Embroidered Maxi Dress")
    WebElement maxidress;
    @FindBy(linkText = "Frozen Tops For Kids")
    WebElement topforkids;
    
    public void removeProductFromCart()
    {
    	removeProduct.click();
    	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public void goBackToProducts()
    {
    	backToProducts.click();
    }
    public void proceedToCheckout()
    {
    	ProceedtocChkOutButton.click();
    }
    public String verifyRemoval(){
    	String s=verifyRemove.getText();
        return s;
    }
    public String maxidress()
    {
    	return maxidress.getText();
    }
    public String topforkids()
    {
    	return topforkids.getText();
    }
}

