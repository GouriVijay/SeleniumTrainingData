package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupOrLoginPom {
	public static WebDriver driver;

	public SignupOrLoginPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@name=\"name\"]")
	WebElement uname;
	@FindBy(xpath = "(//input[@name=\"email\"])[2]")
	WebElement mail;
	@FindBy(xpath = "(//button[@type=\"submit\"])[2]")
	WebElement signup;
	@FindBy(xpath = "(//input[@type=\"email\"])[1]")
	WebElement email;
	@FindBy(xpath = "//input[@type=\"password\"]")
	WebElement pwd;
	@FindBy(xpath = "(//button[@type=\"submit\"])[1]")
	WebElement login;
	@FindBy(xpath = "(//div//form//p)[1]")
	WebElement logError;

	public void clickName(String name) {
		uname.sendKeys(name);
	}

	public void clickEmail(String email) {
		mail.sendKeys(email);
	}

	public void clickSignup() {
		signup.click();
	}

	public void loginEmail(String email1) {
		email.sendKeys(email1);
	}

	public void loginpwd(String pwd1) {
		pwd.sendKeys(pwd1);
	}

	public void clicklogin() {
		login.click();
	}

	public String loginError() {
		String s = logError.getText();
		return s;
	}
}
