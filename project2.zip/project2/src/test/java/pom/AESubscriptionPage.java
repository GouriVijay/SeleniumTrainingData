
package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AESubscriptionPage {
	public static WebDriver driver;

	public AESubscriptionPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "susbscribe_email")
	WebElement SubscriptionMail;
	@FindBy(xpath = "//button[@id='subscribe']")
	WebElement clickSubmit;
	@FindBy(name = "csrfmiddlewaretoken")
	WebElement verifySubscription;

	public void enterSubscriptionMail() {
		SubscriptionMail.sendKeys("gayathrigauri3621@gmail.com");
	}

	public void submitMail() {
		clickSubmit.click();
	}

	public boolean ifSubscribed() {
		return verifySubscription.isEnabled();
	}
}
