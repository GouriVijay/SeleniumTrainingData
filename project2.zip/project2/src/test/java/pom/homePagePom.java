package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class homePagePom {
	public static WebDriver driver;

	public homePagePom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@href=\"/login\"]")
	WebElement signupOrLogin;
	@FindBy(xpath = "//li//a[@href=\"/contact_us\"]")
	WebElement contactUs;
	@FindBy(xpath = "//li//a[@href=\"/logout\"]")
	WebElement vLogin;

	public void clickSignupOrLogin() {
		signupOrLogin.click();
	}

	public void clickContactUs() {
		contactUs.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String verifyLogin() {
		String s = vLogin.getText();
		return s;
	}

}
