package pom;
 
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
 
public class AEProductsPom {
	private static WebDriver driver;
 
    public AEProductsPom(WebDriver driver){
    	AEProductsPom.driver = driver;
    	PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//div[@class='shop-menu pull-right']/ul/li[2]/a")
    WebElement products;
    
    @FindBy(id = "search_product")
    WebElement searchBar;
    
    @FindBy(id = "submit_search")
    WebElement submitSearch;
    
    @FindBy(xpath = "//div[@class='brands-name']/ul/li[2]/a")
    WebElement HandM;
    
    @FindBy(xpath = "(//div[@class='productinfo text-center'])[1]/a")
    WebElement HandMprodut1;
    
    @FindBy(xpath = "(//div[@class='productinfo text-center'])[2]/a")
    WebElement HandMprodut2;
    
    @FindBy(xpath = "(//span[@class='badge pull-right'])[1]")
    WebElement women;
    
    @FindBy(xpath = "(//div[@class='panel-body'])[1]/ul/li[1]/a")
    WebElement dress;
    
    @FindBy(xpath = "(//div[@class='choose'])[3]/ul/li/a")
    WebElement viewDress;
    
    @FindBy(xpath = "//button[@class='btn btn-default cart']")
    WebElement addToCart;
    
    @FindBy(xpath = "//button[@class='btn btn-success close-modal btn-block']")
    WebElement continueShopping;
    
    @FindBy(xpath = "//div[@class='brands-name']/ul/li[6]/a")
    WebElement allenSollyJr;
    
    @FindBy(xpath = "(//div[@class='choose'])[1]/ul/li/a")
    WebElement viewAllenSollyJr;
    
    @FindBy(xpath = "//input[@id='quantity']")
    WebElement quantity;
    
    @FindBy(linkText = "View Cart")
    WebElement viewCartBtn;
    
    @FindBy(xpath = "//div[@class='shop-menu pull-right']/ul/li[4]/a")
    WebElement logout;
    
	@FindBy(xpath="(//div[@class='productinfo text-center'])/a")
	List<WebElement> ValidProducts;
	
	@FindBy(xpath="(//div[@class='productinfo text-center'])/a")
	List<WebElement> InvalidProducts;
    
//    
//    List<WebElement> ValidProducts= driver.findElements(By.xpath("(//div[@class='productinfo text-center'])/a"));//number of valid products
//	List<WebElement> InvalidProducts= driver.findElements(By.xpath("(//div[@class='productinfo text-center'])/a"));//number of invalid products
 
    
    public void goToProducts()
    {
    	products.click();
    }
    
    public void selectWomenInCategory()
    {
    	women.click();
    }
    public void selectDressForWomen()
    {
    	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	dress.click();
    }
    public void clickViewDress()
    {
    	viewDress.click();
    }
    public void clickAddToCart()
    {
    	addToCart.click();
    }
    public void clickContinueShopping()
    {
    	continueShopping.click();
    }
    public void clickAllenSollyJunior()
    {
    	allenSollyJr.click();
    }
    public void viewAllenSollyJunior()
    {
    	viewAllenSollyJr.click();
    }
    public void selectQuantity()
    {
    	quantity.clear();
    	quantity.sendKeys("2");
    }
    public void selectHandMBrand()
    {
    	HandM.click();
    	
    }
    public void addHandMProductsToCart()
    {
    	HandMprodut1.click();
    	continueShopping.click();
    	HandMprodut2.click();
    }
    public void clickViewCart()
    {
    	viewCartBtn.click();
    }
    public void searchForValidItem()
    {
    	searchBar.sendKeys("saree");
    	submitSearch.click();
    }
    public void searchForInvalidItem()
    {
    	searchBar.clear();
    	searchBar.sendKeys("toys");
    	submitSearch.click();
    }
    public int getNumberOfValidProducts()
    {
    	return ValidProducts.size();
    }
    
    public int getNumberOfInvalidProducts()
    {
    	return InvalidProducts.size();
    }
   
}
