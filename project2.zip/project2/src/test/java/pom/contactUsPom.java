package pom;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class contactUsPom {
	 public static WebDriver driver;
	   
	  public contactUsPom(WebDriver driver) {
		  this.driver=driver;
		  PageFactory.initElements(driver, this);
	  }
	  
	  @FindBy(xpath = "(//div[@class='form-group col-md-6'])[1]/input")
	  WebElement name1;
	  @FindBy(xpath = "(//div[@class=\"form-group col-md-6\"])[2]/input")
	  WebElement email1;
	  @FindBy(xpath = "(//div[@class=\"form-group col-md-12\"])[1]/input")
	  WebElement sub;
	  @FindBy(xpath = "(//div[@class=\"form-group col-md-12\"])[2]/textarea")
	  WebElement msg;
	  @FindBy(xpath = "//div//input[@type=\"submit\"]")
	  WebElement submit;
	  @FindBy(xpath = "//div[@class=\"contact-form\"]//div[@class=\"status alert alert-success\"]")
	  WebElement Vsubmit;
	  @FindBy(xpath = "//div[@id=\"form-section\"]//a")
	  WebElement home;
	  
	  
	  public void enterName(String name) {
		  name1.sendKeys(name);
	  }
	  public void enterEmail(String email) {
		  email1.sendKeys(email);
	  }
	  public void enterSubject(String subject) {
		  sub.sendKeys(subject);
	  }
	  public void enterMessage(String message) {
		  msg.sendKeys(message);
	  }
	  public void clickSubmit() {
		  submit.click();
		  Alert a=driver.switchTo().alert();
	      a.accept();
	  }
	  public String verifySubmit() {
		  String s=Vsubmit.getText();
		  return s;
	  }
	  public void clickHome() {
		  home.click();
	  }
	  
	  
	
	
}
