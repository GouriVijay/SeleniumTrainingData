
package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AECheckoutPom {
	private static WebDriver driver;

	public AECheckoutPom(WebDriver driver){
		AECheckoutPom.driver = driver;
		PageFactory.initElements(driver, this); 
	}
	// Place order
	@FindBy(xpath = "//a[@class='btn btn-default check_out']")
	WebElement PlaceOrderButton;
	// Name on the card box
	@FindBy(xpath = "//input[@class='form-control']")
	WebElement NameonCardBox;
	// Card number box
	@FindBy(xpath = "//input[@class='form-control card-number']")
	WebElement CardNumberBox;
	// CVV box
	@FindBy(xpath = "//input[@class='form-control card-cvc']")
	WebElement CVVBox;
	// month box
	@FindBy(xpath = "//input[@class='form-control card-expiry-month']")
	WebElement MonthBox;
	// year box
	@FindBy(xpath = "//input[@class='form-control card-expiry-year']")
	WebElement YearBox;
	// pay and confirm order button
	@FindBy(xpath = "//button[@class='form-control btn btn-primary submit-button']")
	WebElement ConfirmButton;
	// Order Placed! text
	@FindBy(xpath = "//h2[@class='title text-center']")
	WebElement ConfirmText;
	// continue button
	@FindBy(xpath = "//a[@class='btn btn-primary']")
	WebElement ContinueButton;
	public void placeOrder()
	{
		PlaceOrderButton.click();
	}
	public void enterNameOnCard()
	{
		NameonCardBox.sendKeys("Pokemon");
	}
	public void enterCardNumber()
	{
		CardNumberBox.sendKeys("5417542146418");
	}
	public void enterCVV()
	{
		CVVBox.sendKeys("671");
	}
	public void enterMonth()
	{
		MonthBox.sendKeys("08");
	}
	public void enterYear()
	{
		YearBox.sendKeys("2001");
	}
	public void clickConfirmBtn()
	{
		ConfirmButton.click();
	}
	public void clickContinueBtn()
	{
		ContinueButton.click();
	}

}


