package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPom {
	public static WebDriver driver;

	public SignupPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//label[@class=\"top\"])[2]")
	WebElement title;
	@FindBy(xpath = "//input[@type=\"password\"]")
	WebElement pwd;
	@FindBy(xpath = "(//div[@class=\"selector\"])[1]")
	WebElement date;
	@FindBy(xpath = "(//select//option[@value=\"9\"])[1]")
	WebElement date1;
	@FindBy(xpath = "(//div[@class=\"selector\"])[2]")
	WebElement month;
	@FindBy(xpath = "(//select//option[@value=\"3\"])[2]")
	WebElement month1;
	@FindBy(xpath = "(//div[@class=\"selector\"])[3]")
	WebElement year;
	@FindBy(xpath = "//select//option[@value=\"2001\"]")
	WebElement year1;
	@FindBy(xpath = "(//div//span//input[@type=\"checkbox\"])[1]")
	WebElement newsletter;
	@FindBy(xpath = "(//div//span//input[@type=\"checkbox\"])[2]")
	WebElement specialOffer;
	@FindBy(xpath = "(//p//input)[1]")
	WebElement firstname;
	@FindBy(xpath = "(//p//input)[2]")
	WebElement lastname;
	@FindBy(xpath = "(//p//input)[3]")
	WebElement company1;
	@FindBy(xpath = "(//p//input)[4]")
	WebElement address1;
	@FindBy(xpath = "(//p//input)[6]")
	WebElement state1;
	@FindBy(xpath = "(//p//input)[7]")
	WebElement city1;
	@FindBy(xpath = "(//p//input)[8]")
	WebElement zip1;
	@FindBy(xpath = "(//p//input)[9]")
	WebElement number;
	@FindBy(xpath = "(//button[@type=\"submit\"])[1]")
	WebElement createAccount;
	@FindBy(xpath = "//h2//b")
	WebElement verifycreation;
	@FindBy(linkText = "Continue")
	WebElement clickcontinue;
	@FindBy(xpath = "//div[@class=\"col-sm-4\"]//form//p[1]")
	WebElement error;
	@FindBy(xpath = "//a[@href=\"/delete_account\"]")
	WebElement delete;
	@FindBy(xpath = "//h2//b")
	WebElement Vdelete;
	@FindBy(xpath = "//div[@class=\"pull-right\"]//a")
	WebElement clickcontinue1;

	public void clickTitle() {
		title.click();
	}

	public void EnterPwd(String pwd1) {
		pwd.sendKeys(pwd1);
	}

	public void clickDob() {
		date.click();
		date1.click();
		month.click();
		month1.click();
		year.click();
		year1.click();
	}

	public void clickCheckBox() {
		newsletter.click();
		specialOffer.click();
	}

	public void AddressInfo1(String first, String second, String num) {
		firstname.sendKeys(first);
		lastname.sendKeys(second);
		number.sendKeys(num);
	}

	public void AddressInfo2(String company, String address, String state, String city, String zip) {
		company1.sendKeys(company);
		address1.sendKeys(address);
		state1.sendKeys(state);
		city1.sendKeys(city);
		zip1.sendKeys(zip);
	}

	public void createAccount() {
		createAccount.click();
	}

	public String verifyCreation() {
		String s = verifycreation.getText();
		return s;
	}

	public void clickContinue() {
		clickcontinue.click();
	}

	public String errorMessage() {
		String s1 = error.getText();
		return s1;
	}

	public void deleteAccount() {
		delete.click();
		clickcontinue1.click();
	}

	public String verifyDelete() {
		String s2 = Vdelete.getText();
		return s2;
	}

}
