package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
	
	@CucumberOptions(
			//tags="@positive",
			glue="UST.project2",
			features="C:\\Users\\269657\\eclipse-workspace\\project2\\src\\test\\resources\\features"
	        )
	public class TestRunner extends AbstractTestNGCucumberTests {

	}


