package jpetStoreTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.DriverSetup;
import base.ReusableMethods;
import pageObjects.productPom;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

//Listener for generating Extent Reports for test execution tracking
@Listeners(utilities.ExtentReportsListener.class)
public class JPetStoreTest {
	public static WebDriver driver;
	public static ReusableMethods re;
	public static productPom products;

	@BeforeMethod(groups= {"add","search"})
	public void before() throws InterruptedException
	{

		driver= DriverSetup.invokeEgde();
		re= new ReusableMethods(driver);
		re.openWebsite();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		products = new productPom(driver);
		products.clickSignIn();
		products.enterCredentials();
		products.clickLoginBtn();
		ExtentReportsListener.setDriver(driver);
	}

	//test to add product to cart
	@Test(priority=1,groups="add")
	public void jpetAddProductTest() throws InterruptedException
	{
		products = new productPom(driver);

		products.clickCats();//click cats in product page
		products.clickPersian(); //click persian
		products.clickFemalePersian(); //select female persian
		products.clickAddToCart();//add selected to cart
		System.out.println(products.verifyCart());
		assertEquals(products.verifyCart(),"Adult Female Persian");//verify if product added to cart

	}

//	// DataProvider for test data
//	@DataProvider(name="productToSearch")
//	public String[][] getLoginData() throws IOException {
//		String path = "C:\\Users\\269657\\eclipse-workspace\\JPetStore\\excelData\\Book2.xlsx";
//		String sheet = "Sheet1";
//		return ExcelHandling.fetchUserDetails(path, sheet); // Fetch data from Excel sheet
//	}
//
//	//test to search a product based on the data fetched from excel
//	@Test(dataProvider = "productToSearch", priority = 2,groups="search")
//	public void jpetSearchTest(String productName) throws InterruptedException
//	{
//		products = new productPom(driver);
//		products.searchForProduct(productName);
//		assertTrue(products.verifySearchSuccess().contains("Labrador"));
//	}


	// Method to capture a screenshot of failed test cases
	@AfterMethod(groups= {"add","search"})
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
