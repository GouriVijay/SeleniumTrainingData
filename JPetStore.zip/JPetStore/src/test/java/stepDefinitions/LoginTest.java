package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LoginPom;

@Listeners
public class LoginTest {
	private final WebDriver driver= Hooks.driver;
	public LoginPom login;
	
	//method to open website
	@Given("User already open the website JPetStore")
	public void user_already_open_the_website_j_pet_store() {
		assertEquals(driver.getCurrentUrl(), "https://petstore.octoperf.com/actions/Catalog.action");
	}
	
	//method to click signin
	@When("User click on SignIn option")
	public void user_click_on_sign_in_option() {
		login=new LoginPom(driver);
		login.clickSignIn();	  
	}

	//method to enter name
	@When("User input {string} name")
	public void user_input_name(String string) throws InterruptedException {
		login=new LoginPom(driver);
		login.enterName(string);
	}
	
	//method to enter password
	@When("User input {string} as password")
	public void user_input_as_password(String string) throws InterruptedException {
		login=new LoginPom(driver);
		Thread.sleep(1000);
		login.enterPwd(string);
	}

    //method to click login
	@When("User click login button")
	public void user_click_login_button() {
		login=new LoginPom(driver);
		login.clickSubmit();
	}

	//method to check logged in successfully
	@Then("User successfully logged in")
	public void user_successfully_logged_in() {
		assertEquals(driver.getCurrentUrl(), "https://petstore.octoperf.com/actions/Catalog.action");
	}

	@Then("User on login page itself")
	public void user_on_login_page_itself() {
		assertEquals(driver.getCurrentUrl(), "https://petstore.octoperf.com/actions/Account.action");

		
	}

}
