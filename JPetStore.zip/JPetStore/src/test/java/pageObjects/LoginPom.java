package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPom {
	public static WebDriver driver;
	
	public LoginPom(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//div[@id='Menu']/div/a[2]")
	WebElement signin;
	
	@FindBy(css = "input[name='username']")
	WebElement name;
	
	@FindBy(css = "input[name='password']")
	WebElement pwd;
	
	@FindBy(xpath = "(//input[@type='submit'])[2]")
	WebElement submitLogin;
	
	public void clickSignIn()
	{
		signin.click();
	}
	
	public void enterName(String username) throws InterruptedException
	{
		name.sendKeys(username);
	}
	public void enterPwd(String password) throws InterruptedException
	{
		Thread.sleep(2000);		
		pwd.clear();
		pwd.sendKeys(password);
	}
	
	public void clickSubmit()
	{
		submitLogin.click();
	}

}
