package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class productPom {
	public static WebDriver driver;

	public productPom(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath = "//div[@id='Menu']/div/a[2]")
	WebElement signin;

	@FindBy(css = "input[name='username']")
	WebElement username;

	@FindBy(xpath = "//input[@name='password']")
	WebElement password;

	@FindBy(xpath = "(//input[@type='submit'])[2]")
	WebElement submitLogin;

	@FindBy(xpath = "//div[@id='QuickLinks']/a[4]")
	WebElement cat;

	@FindBy(xpath = "//div[@id='Catalog']/table/tbody/tr[3]/td[1]/a")
	WebElement persian;

	@FindBy(xpath = "//div[@id='Catalog']/table/tbody/tr[2]/td[1]/a")
	WebElement femalePersian;

	@FindBy(xpath = "//div[@id='Catalog']/table/tbody/tr[7]/td/a")
	WebElement addToCart;
	
	@FindBy(xpath = "//form/table/tbody/tr[2]/td[3]")
	WebElement verify;

	@FindBy(xpath = "//div[@id='SearchContent']/form/input[1]")
	WebElement searchBar;

	@FindBy(xpath = "//div[@id='SearchContent']/form/input[2]")
	WebElement submitSearch;

	@FindBy(xpath = "//div[@id='Catalog']/table/tbody/tr[2]/td[3]")
	WebElement verifySearch;

	public void clickSignIn()
	{
		signin.click();
	}
	public void enterCredentials() throws InterruptedException
	{
		username.sendKeys("gouri");
		Thread.sleep(1000);
		password.clear();
		password.sendKeys("asdfg");
	}
	public void clickLoginBtn()
	{
		submitLogin.click();
	}
	public void clickCats()
	{
		cat.click();
	}
	public void clickPersian()
	{
		persian.click();
	}
	public void clickFemalePersian()
	{
		femalePersian.click();
	}
	public void clickAddToCart()
	{
		addToCart.click();
	}
	public String verifyCart() {
		return verify.getText();
	}

	public void searchForProduct(String s)
	{
		searchBar.sendKeys(s);
		submitSearch.click();
	}
	public String verifySearchSuccess()
	{
		return verifySearch.getText();
	}

}



