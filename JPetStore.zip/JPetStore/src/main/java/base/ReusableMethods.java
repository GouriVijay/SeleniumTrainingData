package base;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.PropertyFile;

public class ReusableMethods {
	public static WebDriver driver;
	public static Properties properties;
	public ReusableMethods(WebDriver driver)
	{
		this.driver=driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		properties= PropertyFile.getProperties();
	}

	public static WebDriver invokeBrowser()
	{
		if(properties==null)
		{
			properties=PropertyFile.getProperties();
			String browserChoice= properties.getProperty("browser2");
			try {
				if (browserChoice.equalsIgnoreCase("chrome")) {
					driver = DriverSetup.invokeChrome();
				} else if (browserChoice.equalsIgnoreCase("edge")) {
					driver = DriverSetup.invokeEgde();
				}else {
					throw new Exception("Invalid browser name provided in property file");
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return driver;
	}
	
	public void openWebsite()
	{
		try {
			driver.get(properties.getProperty("testSiteURL"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void openProductsPage()
	{
		try {
			driver.get(properties.getProperty("testSiteURL1"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void switchToNewTab() {
		try {
			
			ArrayList<String> tabs = new ArrayList<String>(
					driver.getWindowHandles());
			driver.switchTo().window(tabs.get(tabs.size() - 1));
		
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	/************** Switch to prev tab ****************/
	public static void switchToPrevTab() {
		try {
			ArrayList<String> tabs = new ArrayList<String>(
					driver.getWindowHandles());
			driver.close();
			driver.switchTo().window(tabs.get(tabs.size() - 2));
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
}
