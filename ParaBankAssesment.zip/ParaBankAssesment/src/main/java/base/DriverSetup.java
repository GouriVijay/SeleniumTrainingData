package base;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class DriverSetup {
	public static WebDriver driver;
	
	public static WebDriver invokeEdge() {
		EdgeOptions options=new EdgeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");
		driver=new EdgeDriver(options);
		return driver;
	}
	
	public static WebDriver invokeChrome() {
		ChromeOptions options=new ChromeOptions();
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");
		driver=new  ChromeDriver(options);
		return driver;
		
				
		
	}

}

