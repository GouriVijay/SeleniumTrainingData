package runner;
import org.testng.annotations.Listeners;

import io.cucumber.testng.CucumberOptions;
import utilities.ExtentReportsListener;

@CucumberOptions(
		tags="@negative",
		glue="cucumberTest",
		features="C:\\Users\\269657\\eclipse-workspace\\ParaBankAssesment\\src\\test\\resources\\features\\parabankLogin.feature"
		)
@Listeners(utilities.ExtentReportsListener.class)
public class TestRunner {
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
}


