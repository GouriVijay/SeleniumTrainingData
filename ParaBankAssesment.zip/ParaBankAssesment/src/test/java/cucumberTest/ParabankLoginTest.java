package cucumberTest;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePage;

public class ParabankLoginTest {
	private final WebDriver driver= Hooks.driver;
	
	@Given("User open the website ParaBank")
	public void user_open_the_website_para_bank() {
		//implicit wait for 2 second in order to load the website
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		//verify url 
		assertEquals(driver.getCurrentUrl(), "https://parabank.parasoft.com/parabank/index.htm");
	    
	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String string, String string2) {
		//creating object for homepage pom
	   HomePage home=new HomePage(driver);
	   //calling method nameAndpwd from homepage pom 
	   home.nameAndPwd(string, string2);
	}

	@When("User click on Login button")
	public void user_click_on_login_button() {
	   HomePage home=new HomePage(driver);
	   //calling clickLogin method from homepage pom 
	   home.clickLogin();
	}

	@Then("User logged in successfully")
	public void user_logged_in_successfully() {
		HomePage home=new HomePage(driver);
		assertEquals(home.verifyLogin(), "Welcome gouri b");

	}

	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		HomePage home=new HomePage(driver);
		assertEquals(home.errorMessage(),string);
		

	}
}
