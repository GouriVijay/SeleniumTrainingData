package cucumberTest;

import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	public static WebDriver driver;
    private ExtentReports extent;
    private ExtentTest test;
 
    @Before
    public void openBrowser(){
        String appUrl = " https://parabank.parasoft.com/parabank/index.htm";
        driver = new EdgeDriver();
        driver.get(appUrl);
        driver.manage().window().maximize();
 
        // Initialize the Extent reports with the HTML reporter
        ExtentSparkReporter reporter = new ExtentSparkReporter("extent.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
 
        // Create a new test
        test = extent.createTest("Demo");
    }
 
    @After
    public void closeBrowser(){
    	//taking the screenshot after every test
    			java.io.File screenshotfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    			try {
    				Date d1 = new Date();
    				FileUtils.copyFile(screenshotfile, new File("screenshots/"+ d1.getTime()+ "ss.jpg"));
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
        //Take the screenshot
        final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        //Add it to the report
        test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
        test.pass("Test passed");
        extent.flush();
        driver.quit();
        
       
    }

}
