package paraBankTest;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.security.auth.login.LoginContext;

import org.apache.commons.io.FileUtils;
import org.checkerframework.checker.units.qual.Acceleration;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Excel.ExcelHandling1;
import base.ReusableMethods;
import pom.AccountPom;
import pom.LoginPom;
import pom.RegisterPom;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class ParaBankTest implements ITestListener{
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	public static WebDriver driver;
    public static ReusableMethods reusableMethods;
    public RegisterPom register;
    
    @BeforeClass
   	public void setup()
   	{
    	//invoke edge browser by calling invokeBrowser method from ReusableMethods
   		driver = ReusableMethods.invokeBrower();
   		reusableMethods = new ReusableMethods(driver);
   	
   	}
    
    @BeforeMethod
	public void before()
	{
    	//Open the website ParaBank by calling openWebsite method from reusablemethods
		reusableMethods.openWebsite();
	}
    
    //used to fetch password from excel
    @DataProvider(name="password")
   	public String[][] getRemoveFromCartData() throws IOException
   	{
   		String path="C:\\Users\\269657\\eclipse-workspace\\ParaBankAssesment\\ExcelData\\Book1.xlsx";
   		String sheet="sheet1";
   		return ExcelHandling1.fetchUserDetails(path, sheet);
   	}
    
    
    
    
    //test scenario to Register user
    @Test(dataProvider = "password")
    public void RegisterUser(String pwd){
    	//created object for registerpom 
    	RegisterPom register=new RegisterPom(driver);
    	register.clickRegister();   //click register
    	register.details();         //enter user details
    	register.username();     //enter user name and password
    	register.password(pwd);  //password is fetched from excel
    	register.confirmRegister(); //click register button
    	
    	//verified registration by checking success message
    	assertEquals(register.registerSuccess(), "Your account was created successfully. You are now logged in.");
    	
    }
    
    
   
    @Test
    public void OpenAccount() {
    	
    	LoginPom login=new LoginPom(driver);
    	AccountPom account=new AccountPom(driver);
    	//login to user account
    	login.Login();
    	
    	//click open new account
    	account.clickOpenAccount();
    	
    	//choose account type and submit
    	account.chooseType();
    	
    	//verify account creation
    	assertEquals(driver.getCurrentUrl(), "https://parabank.parasoft.com/parabank/openaccount.htm");
    }
    
    
    
    @AfterMethod
   	public void after() {
   		//taking the screenshot after every test
   		java.io.File screenshotfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
   		try {
   			Date d1 = new Date();
   			FileUtils.copyFile(screenshotfile, new File("screenshots/"+ d1.getTime()+ "ss.jpg"));
   	} catch (IOException e) {
   		e.printStackTrace();
   	}
   	}
    
    

    
}
