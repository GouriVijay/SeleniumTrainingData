package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	public static WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//xpath to locate username field
    @FindBy(xpath = "(//div[@class='login'])[1]//input")
    WebElement username;
    
  //xpath to locate password field
    @FindBy(xpath = "(//div[@class='login'])[2]//input")
    WebElement password;
    
  //xpath to locate login button
    @FindBy(xpath = "(//div[@class='login'])[3]//input")
    WebElement login;
    
  //xpath to verify login - checks welcome message
    @FindBy(xpath = "//div[@id='leftPanel']//p")
    WebElement verify;
    
  //xpath to loacte error if invalid login occur
    @FindBy(xpath = "//div[@id='rightPanel']//p")
    WebElement error;
    
  
    
    
    public void nameAndPwd(String name,String pwd) { //click the register option
		username.sendKeys(name);
		password.sendKeys(pwd);
	}
    
    public void clickLogin() {
    	login.click();
    }
    
    public String verifyLogin() {
    	String s=verify.getText();
    	return s;
    }
    
    public String errorMessage() {
    	String s1=error.getText();
    	return s1;
    }
    
    
}
