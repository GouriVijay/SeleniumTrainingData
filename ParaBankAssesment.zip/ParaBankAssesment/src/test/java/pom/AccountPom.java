package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountPom {
	public static WebDriver driver;
	public AccountPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//locate open account link
	@FindBy(linkText = "Open New Account")
	WebElement openAccount;
	
	//locate type of account
	@FindBy(xpath ="//select[@id='type']")
	WebElement type;
	@FindBy(xpath ="//select[@id='type']//option[2]")
	WebElement savings;
	
	@FindBy(xpath ="//select[@id=\"fromAccountId\"]")
	WebElement number;
	@FindBy(xpath ="//select[@id=\"fromAccountId\"]//option")
	WebElement number1;
	
	
	
    //locate open new account
	@FindBy(xpath = "(//div)[9]//input[@type=\"submit\"]")
	WebElement submit1;
	
	//locate success message of account creation
	@FindBy(xpath = "//div[@class='ng-scope']//p[1]")
	WebElement message;
	
	//method to click open account
	public void clickOpenAccount() {
		openAccount.click();
	}
	
	//method to choose account type
	public void chooseType() {
		type.click();
		savings.click();
		number.click();
		number1.click();
	}
	
	//method to submit account creation
	public void submit() {
		submit1.click();
	}
	
	//method to verify success message of account creation
	public String verifyAccountCreation() {
		return message.getText();
	}
	
	
	
	
	
	

}
