package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPom {
	public static WebDriver driver;
	public LoginPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//locate register button
	@FindBy(linkText = "Register")
	WebElement register;
	
	//locate firstname
	@FindBy(xpath = "//table//tr[1]//td[2]//input")
	WebElement firstname;
	
	//locate lastname
	@FindBy(xpath = "//table//tr[2]//td[2]//input")
	WebElement lastname;
	
	//locate address
	@FindBy(xpath = "//table//tr[3]//td[2]//input")
	WebElement address;
	
	//locate city
	@FindBy(xpath = "//table//tr[4]//td[2]//input")
	WebElement city;
	
	//locate state
	@FindBy(xpath = "//table//tr[5]//td[2]//input")
	WebElement state;
	
	//locate zip
	@FindBy(xpath = "//table//tr[6]//td[2]//input")
	WebElement zip;
	
	//locate phone
	@FindBy(xpath = "//table//tr[7]//td[2]//input")
	WebElement phone;
	
	//locate ssn
	@FindBy(xpath = "//table//tr[8]//td[2]//input")
	WebElement ssn;
	
	//locate username
	@FindBy(xpath = "//table//tr[10]//td[2]//input")
	WebElement username;
	
	//locate password
	@FindBy(xpath = "//table//tr[11]//td[2]//input")
	WebElement password;
	
	//locate confirm
	@FindBy(xpath = "//table//tr[12]//td[2]//input")
	WebElement confirm;
	
	//locate register button
	@FindBy(xpath = "//table//tr[13]//td[2]//input")
	WebElement confirmRegister;
	
	
	
	
	
	//method to enter user details
	public void Login() {
		register.click();
		firstname.sendKeys("Neha");
		lastname.sendKeys("biju");
		address.sendKeys("ust");
		city.sendKeys("tvm");
		state.sendKeys("kerala");
		zip.sendKeys("690001");
		phone.sendKeys("9990999000");
		ssn.sendKeys("SSN");
		username.sendKeys("lu");
		password.sendKeys("12345");
		confirm.sendKeys("12345");
		confirmRegister.click();
	}
	
	
	
}
