package base;

import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import utilities.PropertyFile;
import base.DriverSetup;

public class ReusableMethods {
	public static WebDriver driver;
	public static Properties properties;
	
	public ReusableMethods(WebDriver driver) {
		this.driver=driver;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		properties=PropertyFile.getProperties();
	}
	
	public static WebDriver invokeBrower() {
		properties=PropertyFile.getProperties();
		try {
		String browserChoice=properties.getProperty("browser1");
		if(browserChoice.equalsIgnoreCase("edge"))
			driver=DriverSetup.invokeEdge();
		else if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = DriverSetup.invokeChrome();
		}else {
			throw new Exception("Invalid browser name provided in property file");
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return driver;
	}
	

	public void openWebsite() {
		driver.get(properties.getProperty("url"));
	}
	
	
	
}
