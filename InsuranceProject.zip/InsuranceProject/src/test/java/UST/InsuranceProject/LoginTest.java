package UST.InsuranceProject;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {
	public class RegisterTest {
		private final WebDriver driver= Hooks.driver;

		@When("User input {string} as emailID {string} as password")
		public void user_input_as_email_id_as_password(String string, String string2) {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}

		@When("User click login button")
		public void user_click_login_button() {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}

		@Then("User successfully logged in")
		public void user_successfully_logged_in() {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}

		@Given("User already open the insurance broker system")
		public void user_already_open_the_insurance_broker_system() {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}

		@Then("User get {string} as invalid login error message")
		public void user_get_as_invalid_login_error_message(String string) {
		    // Write code here that turns the phrase above into concrete actions
		    throw new io.cucumber.java.PendingException();
		}
}
}
