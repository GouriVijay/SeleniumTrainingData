package UST.InsuranceProject;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePagePom;
import pom.SignupPom;

public class RegisterTest {
	private final WebDriver driver= Hooks.driver;
	
	@Given("User already open the website insurance broker system")
	public void user_already_open_the_website_insurance_broker_system() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		assertEquals(driver.getCurrentUrl(), "https://demo.guru99.com/insurance/v1/index.php");

	}

	@When("User click register option")
	public void user_click_register_option() {
	    HomePagePom home=new HomePagePom(driver);
	    home.clickRegister();  //user click on register icon in home page
	}

	//check if user is on register page
	@Then("User is on register page")
	public void user_is_on_register_page() {
	   assertEquals(driver.getCurrentUrl(), "https://demo.guru99.com/insurance/v1/register.php");
	}

	//user enter name and number
	@When("User input {string} as firstname {string} as surname {string} as phone")
	public void user_input_as_firstname_as_surname_as_phone(String string, String string2, String string3) {
		 SignupPom signup=new SignupPom(driver);
		 signup.clickTitle(); 
		 signup.nameandphone(string, string2, string3); //enter name and number
	}

    //user enter other details
	@When("User enter other details")
	public void user_enter_other_details() {
		 SignupPom signup=new SignupPom(driver);
		 signup.otherDetails();//click other details in the form 
	}

	//user enter address
	@When("User input {string} as street {string} as city {string} as country {string} as postcode")
	public void user_input_as_street_as_city_as_country_as_postcode(String string, String string2, String string3, String string4) {
		SignupPom signup=new SignupPom(driver);
		signup.address(string, string2, string3, string4);
		}

	//user enter password
	@When("User input {string} as password and {string} as confirm")
	public void user_input_as_password_and_as_confirm(String string, String string2) {
		SignupPom signup=new SignupPom(driver);
		signup.password(string, string2);
	}
     
	//user click on create 
	@When("User click on create")
	public void user_click_on_create() {
		SignupPom signup=new SignupPom(driver);
		signup.clickCreate();
	}
 
	//after valid signup verify user is on homepage
	@Then("User go back to home page")
	public void user_go_back_to_home_page() {
		assertEquals(driver.getCurrentUrl(),"https://demo.guru99.com/insurance/v1/index.php");
	}
	
	//after invalid signup verify user is on register page itself
	@Then("User stays on register page itself")
	public void user_stays_on_register_page_itself() {
		 assertEquals(driver.getCurrentUrl(), "https://demo.guru99.com/insurance/v1/register.php");
	}

}
