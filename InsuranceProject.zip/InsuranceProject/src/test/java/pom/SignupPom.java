package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPom {
	public static WebDriver driver;
	public SignupPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//select[@id=\"user_title\"]")
	WebElement title;
	@FindBy(xpath = "//select[@id=\"user_title\"]//option[@value=\"Miss\"]")
	WebElement miss;
	@FindBy(xpath = "//input[@id=\"user_firstname\"]")
	WebElement first1;
	@FindBy(xpath = "//input[@id=\"user_surname\"]")
	WebElement sur1;
	@FindBy(xpath = "//input[@id=\"user_phone\"]")
	WebElement phone1;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_1i\"]")
	WebElement year;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_1i\"]//option[@value=\"1952\"]")
	WebElement year1;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_2i\"]")
	WebElement month;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_2i\"]//option[@value=\"3\"]")
	WebElement month1;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_3i\"]")
	WebElement date;
	@FindBy(xpath = "//select[@id=\"user_dateofbirth_3i\"]//option[@value=\"5\"]")
	WebElement date1;
	@FindBy(xpath = "//select[@id=\"user_occupation_id\"]")
	WebElement occ;
	@FindBy(xpath = "//select[@id=\"user_occupation_id\"]//option[@value=\"12\"]")
	WebElement engineer;
	@FindBy(xpath = "//input[@name=\"street\"]")
	WebElement street1;
	@FindBy(xpath = "//input[@name=\"city\"]")
	WebElement city1;
	@FindBy(xpath = "//input[@name=\"county\"]")
	WebElement country1;
	@FindBy(xpath = "//input[@name=\"post_code\"]")
	WebElement pc;
	@FindBy(xpath = "//input[@name=\"email\"]")
	WebElement email;
	@FindBy(xpath = "//input[@name=\"password\"]")
	WebElement pwd1;
	@FindBy(xpath = "//input[@name=\"c_password\"]")
	WebElement confirm1;
	@FindBy(xpath = "//input[@name=\"submit\"]")
	WebElement create;
	
	
	//click miss as title
	public void clickTitle() {  
		title.click();
		miss.click();
	}
	
	//enter firstname,surname,number
	public void nameandphone(String first, String sur, String phone) {
		first1.sendKeys(first);
		sur1.sendKeys(sur);
		phone1.sendKeys(phone);
	}
	 
	public void otherDetails() {
		year.click();
		year1.click();
		month.click();
		month1.click();
		date.click();
		date1.click();
		occ.click();
		engineer.click();
	}
	
	public void address(String street,String city,String country,String postcode) {
		street1.sendKeys(street);
		city1.sendKeys(city);
		country1.sendKeys(country);
		pc.sendKeys(postcode);
	}
	
	public void password(String pwd,String confirm) {
		email.sendKeys("gourivijay123@gmail.com");
		pwd1.sendKeys(pwd);
	    confirm1.sendKeys(confirm);
	}
	
	public void clickCreate() {
		create.click();
	}
	
	
}
