package Task;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class PaytmTest {
	public WebDriver driver;
	@Test
	public void paytmTest() throws InterruptedException {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://paytm.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//div[@class=\"_2blcs\"]//div[@class=\"_1YPz_\"]//span")).click();
		Thread.sleep(3000);
		driver.switchTo().frame(0);
		driver.switchTo().frame(0);
		String s=driver.findElement(By.linkText("privacy policy")).getText();
		assertEquals(true, s.contains("privacy policy"));
	}
}
