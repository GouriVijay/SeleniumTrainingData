package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PractoPom {
   public WebDriver driver;

public PractoPom(WebDriver driver) {
	this.driver = driver;
	PageFactory.initElements(driver, this);
}

@FindBy(xpath = "(//div[@class='c-omni-searchbox_wrapper '])[1]//input[@class='c-omni-searchbox c-omni-searchbox--small']")
WebElement loc;

@FindBy(xpath = "//div[@class='c-omni-suggestion-group']//div[@class='c-omni-suggestion-item']")
WebElement tvm;

@FindBy(xpath = "(//div[@class='c-omni-searchbox_wrapper '])[2]//input[@class='c-omni-searchbox c-omni-searchbox--small']")
WebElement doc;

@FindBy(xpath = "(//div[@class=\"c-omni-suggestion-group\"])[1]//div[@class=\"c-omni-suggestion-item\"][1]//span[@class=\"c-omni-suggestion-item__content\"]")
WebElement phy;

@FindBy(xpath = "(//div[@class=\"c-filter__box u-pos-rel c-dropdown\"])[1]")
WebElement gender;

@FindBy(xpath = "(//ul)[1]//li[1]")
WebElement male;

@FindBy(xpath = "(//div[@class=\"c-filter__box u-pos-rel c-dropdown\"])[2]")
WebElement exp;

@FindBy(xpath = "(//ul)[2]//li[2]//span")
WebElement year;

@FindBy(xpath = "//div[@class=\"u-d-inlineblock u-color--white u-c-pointer\"]")
WebElement filter;

@FindBy(xpath = "(//label[@class=\"u-c-pointer u-d-block c-filter__label\"])[2]")
WebElement above;

@FindBy(xpath = "(//div[@class='u-d-inlineblock'])[1]")
WebElement sort;

@FindBy(xpath = "(//ul)[3]//li[2]")
WebElement highlow;


public void clickLocation() {
	loc.clear();
	loc.sendKeys("Thiruvananthapuram");
}

public void clickTvm() {
	tvm.click();
}

public void clickdoc() {
	doc.sendKeys("physician");
}

public void clickPhysician() {
	phy.click();
}

public void clickGender() {
	gender.click();
}

public String clickMale() {
	male.click();
	String s1=male.getText();
	return s1; 
}

public void clickExp() {
	exp.click();
}

public String clickYear() {
	year.click();
	String s2=year.getText();
	return s2;
	
}

public void clickFilters() {
	filter.click();
}

public void clickAbove500() {
	above.click();
}

public void clickSort() {
	sort.click();
}

public void clickHighToLow() {
	highlow.click();
}

   
   
}
