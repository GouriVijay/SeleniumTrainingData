 package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.locators.RelativeLocator;

public class USTIndiaCareersPom {
public WebDriver driver;
	
    public USTIndiaCareersPom(WebDriver driver) {
    	this.driver=driver;
   	 PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath = "//span[@class=\"multiselect dropdown-toggle js-dropdown-location btn btn-link location-btn\"]")
	WebElement location;
    
    @FindBy(partialLinkText = "Thiruvananthapuram")
    WebElement tvm;    
    
    By type=RelativeLocator.with(By.tagName("input")).toLeftOf(By.xpath("//span[@class=\"multiselect dropdown-toggle js-dropdown-location btn btn-link location-btn\"]"));
   
    By experience=RelativeLocator.with(By.tagName("div")).toRightOf(By.xpath("//span[@class=\"multiselect dropdown-toggle js-dropdown-location btn btn-link location-btn\"]"));
    
    @FindBy(partialLinkText = "4")
    WebElement year;   
    
    @FindBy(xpath = "//button[@class=\"btn btn-primary-search pull-right btn-search btn-1-color-theme tooltips js-jobs-filter\"]")
    WebElement button;
    
    @FindBy(xpath = "//div[@class='row result-div text-color customhide']")
    WebElement found;
    
    public void Clicklocation() {
		location.click();
	}
	
	public void clickTvm() {
		tvm.click();
	}
	
	public void clickType() {
		driver.findElement(type).sendKeys("Test Automation");
	}
	
	public void clickExperience() {
		driver.findElement(experience).click();
	}
	
	public void clickYear() {
		year.click();
	}
	
	public void clickSubmit() {
		button.click();
	}
	
	public String validate() {
		String s=found.getText();
		return s;
	}


}
