package com.UST.Assignment2;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WeatherTest {
	public WebDriver driver;
	@BeforeTest
	public void before() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://weather.com");
	}
	
	@Test
	public void whetherTest() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.id("LocationSearch_input")).sendKeys("bangalore");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class=\"Button--default--2gfm1 ListItem--listItem--25ojW SearchedLocations--ListboxOption--3uuhH\"]")).click();
		driver.findElement(By.linkText("10 Day")).click();
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(2));  //explicit sleep
		wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[@type=\"button\"])[26]//span")));
		driver.findElement(By.xpath("(//button[@type=\"button\"])[26]//span")).click();
    	driver.findElement(By.xpath("//div[@class=\"styles--nav--1ZpdN\"]//a[2]//span")).click();
		Thread.sleep(3000);
		WebElement element= driver.findElement(By.xpath("//header[@class='Card--cardHeader--3NRFf']/h2"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",element);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//footer[@id='allPollutantsFooter']/button/span")).click();
		String s=driver.findElement(By.xpath("//div[@class=\"AirQuality--levels--3fDlu\"]//h4")).getText();
		assertEquals(true, s.contains("Levels")); //validation
	}

}
