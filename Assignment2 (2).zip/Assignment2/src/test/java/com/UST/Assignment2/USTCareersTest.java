package com.UST.Assignment2;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.USTCareersPom;
import pom.USTIndiaCareersPom;

public class USTCareersTest {
	public WebDriver driver;
	public USTCareersPom ust;
	public USTIndiaCareersPom ustIndia;
	int i=1;
	@BeforeTest
	public void before() throws InterruptedException {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.ust.com/en/careers");
		Thread.sleep(2000);
		driver.findElement(By.id("onetrust-accept-btn-handler")).click();
		ust=new USTCareersPom(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ustIndia=new USTIndiaCareersPom(driver);
		
	}
	
	@Test(priority=1)
	public void testUSTCareers() throws InterruptedException {
		ust.IndiaCareers1();
		
		String parentWindowHandle = driver.getWindowHandle();
		   Set<String> allWindowHandles = driver.getWindowHandles();
	       for (String windowHandle : allWindowHandles) {
	           if (!windowHandle.equals(parentWindowHandle)) {
	               driver.switchTo().window(windowHandle);
	               break;
	           }
	       }
	       
	      ustIndia.Clicklocation();
	      ustIndia.clickTvm();
	      ustIndia.clickType();
	      ustIndia.clickExperience();
	      ustIndia.clickYear();
	      ustIndia.clickSubmit();
	      Thread.sleep(5000);
	      String s=ustIndia.validate();
	      assertEquals(true,s.contains("17 job(s) found"));
 	      String s1=driver.getCurrentUrl();
 	      assertEquals(true,s1.equalsIgnoreCase("https://usource.ripplehire.com/candidate/?token=xHQWoFn4C242POo7xMpH&source=CAREERSITE#list/search=Test%20Automation&geo=INDIA&location=Thiruvananthapuram&exp=4"));
		}
	
	@AfterMethod
	public void captureScreenshotOfFail(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(screenshot, new File("screenshot/"+ ++i + "screenshot.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		
	}
	
	
	
	
	
	}
	

	}
