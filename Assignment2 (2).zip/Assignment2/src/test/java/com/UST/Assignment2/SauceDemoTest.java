package com.UST.Assignment2;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class SauceDemoTest {
	public static WebDriver driver;
	@Test
	public void setUp() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}		
	@Test(dataProvider = "getLoginData")
	public void testLogin(String username,String password) throws InterruptedException{
		Object[][] logindata =null;
		try
		{
			logindata = getLoginData();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println(logindata.length);
		Thread.sleep(1000);
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);
		driver.get("https://www.saucedemo.com/");
		Thread.sleep(1000);		
	}
	@DataProvider
	public static Object[][] getLoginData()throws IOException{
		Object[][] logindata = FetchDataFromExcel.excelHandling();
		return logindata;
	}
}