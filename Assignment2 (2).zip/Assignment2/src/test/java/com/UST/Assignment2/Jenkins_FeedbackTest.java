package com.UST.Assignment2;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Jenkins_FeedbackTest {
	public WebDriver driver;
	
	
	
	@BeforeTest
	public void before() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.jenkins.io/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	
	
	@Test
    public void testFeedback() throws InterruptedException {
		driver.findElement(By.xpath("//div[@class='mb-2']//a[1]")).click();
		driver.findElement(By.xpath("//div[@class='sidebar-nav tour']//ul[2]//li[1]//a")).click();
		driver.findElement(By.xpath("(//div[@class='sect2'])[2]/p/a")).click();
		driver.findElement(By.xpath("//form[@id='ss-form']//p[1]//input")).click();
		String s=driver.findElement(By.xpath("//form[@id='ss-form']//p[2]//label")).getText();
		String[] s1 =s.split(" ");
		int a=Integer.parseInt(s1[4]);
		int b=Integer.parseInt(s1[6]);
		int ans=a+b;
		String ans1=Integer.toString(ans);
		driver.findElement(By.xpath("//form[@id='ss-form']//p[2]//input")).sendKeys(ans1);
		driver.findElement(By.xpath("//form[@id='ss-form']//p[3]//input")).click();
		Thread.sleep(5000);
		String url=driver.getCurrentUrl();
		System.out.println(url);
		assertEquals(true, url.contains("thank-you-for-your-feedback"));
		
	}
}
