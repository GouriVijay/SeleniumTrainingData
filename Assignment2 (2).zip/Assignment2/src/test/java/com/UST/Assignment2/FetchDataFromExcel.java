package com.UST.Assignment2;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class FetchDataFromExcel {

	public static Object[][] excelHandling() throws IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\269657\\eclipse-workspace\\Assignment2\\TestData\\UnamePassword.xlsx");
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheet("Sheet1");
		int rowCount = sheet.getPhysicalNumberOfRows();
		Row row = sheet.getRow(0);
		int colCount = row.getPhysicalNumberOfCells();
		Object[][] data = new Object[rowCount][colCount];
		for (int i = 0; i < rowCount; i++) {
			for(int j=0;j<colCount;j++) {
				data[i][j] = sheet.getRow(i).getCell(j).getStringCellValue();
			}
		}
		fis.close();
		workbook.close();
		return data;
	}
}









