package com.UST.Assignment2;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.PractoPom;

public class PractoTest {
	public WebDriver driver;
	public PractoPom practo;

	@BeforeTest
	public void before() {
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.practo.com");
		practo = new PractoPom(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@Test
	public void testPracto() throws InterruptedException {
		practo.clickLocation();
		Thread.sleep(2000);
		practo.clickTvm();
		Thread.sleep(3000);
		practo.clickdoc();
		Thread.sleep(3000);
		practo.clickPhysician();
		Thread.sleep(3000);
		practo.clickGender();
		String s1=practo.clickMale();
		assertEquals(true, s1.contains("Male Doctor"));
		Thread.sleep(3000);
		practo.clickExp();
		String s2=practo.clickYear();
		assertEquals(true, s2.contains("10+ Years of experience"));
		Thread.sleep(3000);
		practo.clickFilters();
		practo.clickAbove500();
		Thread.sleep(3000);
		practo.clickSort();
		practo.clickHighToLow();
		;
	}
}
