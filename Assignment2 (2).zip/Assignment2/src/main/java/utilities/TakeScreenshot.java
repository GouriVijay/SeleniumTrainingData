package utilities;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TakeScreenshot {
	
public static void captureScreenshotOfFail(WebDriver driver) {
	
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			Date d=new Date();
			FileUtils.copyFile(screenshot, new File("screenshot1/"+ d.getTime() + "screenshot.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


}
