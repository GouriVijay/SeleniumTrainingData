package com.UST.Assignment2;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utilities.TakeScreenshot;

public class DataProviderDemo {
	public static WebDriver driver;
	@BeforeClass(groups= {"valid","invalid"})
	public void setUp() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
	}	
	
	@BeforeMethod(groups= {"valid","invalid"})
	public void before() {
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	
	
	@DataProvider(name="testdata1")
	public String[][] getData() throws IOException{
		String path="C:\\Users\\269657\\eclipse-workspace\\Assignment2\\TestData\\TestData1.xlsx";
		String sheet="Sheet1";
		return ExcelHandling.excelHandling(path, sheet);
		
	}
	
	@DataProvider(name="testdata2")
	public String[][] getData1() throws IOException{
		String path="C:\\\\Users\\\\269657\\\\eclipse-workspace\\\\Assignment2\\\\TestData\\\\TestData1.xlsx";
		String sheet="Sheet2";
		return ExcelHandling.excelHandling(path, sheet);
		
	}
	
	@Test(dataProvider="testdata1",groups="invalid")
	public void dataprovider(String username,String password) {
//		System.out.println(username);
//		System.out.println(password);
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		assertEquals("https://www.saucedemo.com/",driver.getCurrentUrl());
	}
	
	
	@Test(dataProvider="testdata2",groups="valid")
	public void dataprovider1(String username,String password) throws InterruptedException {
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(3000);
		if(!username.equals("locked_out_user")) {
		assertEquals("https://www.saucedemo.com/inventory.html",driver.getCurrentUrl());
		String s=driver.findElement(By.xpath("//div[@class=\"app_logo\"]")).getText();
		assertEquals(true,s.equalsIgnoreCase("Swag Labs"));
		}
		else
		{
			WebElement e= driver.findElement(By.xpath("//div[@class='error-message-container error']"));
			assertTrue(e.isDisplayed());
			String s1= driver.findElement(By.xpath("//div[@class='login_logo']")).getText();
			assertEquals(true,s1.equalsIgnoreCase("Swag Labs"));
		}
		
	}
	
	@Test(groups="invalid")
	public void testLoginnull() {
		driver.findElement(By.id("login-button")).click();
		WebElement e= driver.findElement(By.xpath("//div[@class='error-message-container error']"));
		assertTrue(e.isDisplayed());
		assertEquals("https://www.saucedemo.com/",driver.getCurrentUrl());
	}
	
	
	
	@AfterMethod(groups= {"valid","invalid"})
	public void after(){
	TakeScreenshot.captureScreenshotOfFail(driver);
	}
	

}
