package com.UST.Assignment2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHandling {
	public static String[][] excelHandling(String path,String sheetName) throws IOException{
		//FileInputStream fis=new FileInputStream("C:\\Users\\269657\\eclipse-workspace\\Assignment2\\TestData\\TestData1.xlsx");
		FileInputStream fis=new FileInputStream(new File(path));
		//for handling excel files we have to use XSSF workbook
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		//Sheet sheet=workbook.getSheet("Sheet1");
		XSSFSheet sheet=workbook.getSheet(sheetName);
		int rowCount = sheet.getPhysicalNumberOfRows();
		Row row=sheet.getRow(0);
		int colCount=row.getPhysicalNumberOfCells();
		System.out.println("no of rows: "+rowCount);
		System.out.println("no of columns: "+colCount);
		String[][] data=new String[rowCount][colCount];
		DataFormatter df=new DataFormatter();//convert to string irrespective of type
		for(int i=0;i<rowCount;i++) {
			for(int j=0;j<colCount;j++) {
				data[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
				
			}
		}
		
		return data;
		
	}
	public static void main(String[] args) throws IOException {
		String[][] s=ExcelHandling.excelHandling("C:\\\\Users\\\\269657\\\\eclipse-workspace\\\\Assignment2\\\\TestData\\\\TestData1.xlsx","Sheet1");
		for(String s1[]:s) {
			for(String s2:s1) {
				System.out.println(s2);
			}
		}
	}

}
