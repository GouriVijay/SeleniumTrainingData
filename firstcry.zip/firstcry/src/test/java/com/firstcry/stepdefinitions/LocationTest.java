package com.firstcry.stepdefinitions;

import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import com.firstcry.pages.LocationPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LocationTest {
	
	private final WebDriver driver= Hooks.driver;
	public LocationPage location;
	
	@When("User click on select location option")
	public void user_click_on_select_location_option() {
	    location = new LocationPage(driver);
	    location.clickSelectLocation();
	}

	@Then("Location is updated successfully")
	public void location_is_updated_successfully() {
		location = new LocationPage(driver);
		System.out.println(location.showDisplayedPincode());
		//verify if the entered pincode is displayed on home page
		assertEquals(location.showDisplayedPincode(), "690504");
	}

	@When("User enter {string} as pincode and click on apply")
	public void user_enter_as_pincode_and_click_on_apply(String string) {
		location = new LocationPage(driver);
	    location.enterPincode(string);
	}

	@Then("User get {string} as error message for invalid location")
	public void user_get_as_error_message_for_invalid_location(String string) {
		location = new LocationPage(driver);
		System.out.println(location.invalidLocationText());
		//verify if error message is displayed for incorrect pincode
		assertEquals(location.invalidLocationText(), string);
	}
}
