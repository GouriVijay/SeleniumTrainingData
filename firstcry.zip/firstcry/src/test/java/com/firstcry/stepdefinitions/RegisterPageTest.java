package com.firstcry.stepdefinitions;

import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.LoginPage;
import com.firstcry.pages.RegisterPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class RegisterPageTest {
	private final WebDriver driver= Hooks.driver;
	public HomePage home;
	public RegisterPage register;
	public LoginPage login;
	
	@Given("User already open the website firstcry")
	public void user_already_open_the_website_firstcry() {
	    assertEquals(driver.getCurrentUrl(), "https://www.firstcry.com/");
	}

	@When("User click on LoginOrRegister option")
	public void user_click_on_login_or_register_option() {
	    home = new HomePage(driver);
	    home.clickloginOrRegister();
	}

	@When("User click on register here option")
	public void user_click_on_register_here_option() {
	   register = new RegisterPage(driver);
	   register.clickRegisterHere();
	}

	@Then("User is on Register page")
	public void user_is_on_register_page() {
		//verify that user is on the register page by checking that the current page title is "Registration"
	   assertEquals(driver.getTitle(), "Registration");
	}

	@When("User input {string} as name {string} as email address {string} as mobile number")
	public void user_input_as_name_as_email_address_as_mobile_number(String string, String string2, String string3) {
		register = new RegisterPage(driver);
		register.enterDetails(string, string2, string3);
	}

	@When("User click on get otp and submit after entering valid otp manually")
	public void user_click_on_get_otp_and_submit_after_entering_valid_otp_manually() {
		register = new RegisterPage(driver);
		register.validateOtp();
	}
	

	@When("User click on get otp")
	public void user_click_on_get_otp() {
		register = new RegisterPage(driver);
		register.clickOtp();
	}

	@Then("User registered successfully")
	public void user_registered_successfully() {
//		assertEquals(driver.getCurrentUrl(), "https://www.firstcry.com/");
		login = new LoginPage(driver);
		assertEquals(login.validLoginVerify(), "My Account");
	}

	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		register = new RegisterPage(driver);
		System.out.println(register.invalidMailText());
	    assertEquals(register.invalidMailText(), string);
	}

	@When("User click on get otp and submit after entering Invalid otp manually")
	public void user_click_on_get_otp_and_submit_after_entering_invalid_otp_manually() {
		register = new RegisterPage(driver);
		register.validateOtp();
	}
	
	@Then("User get {string} as error message for invalid otp")
	public void user_get_as_error_message_for_invalid_otp(String string) {
		register = new RegisterPage(driver);
		System.out.println(register.invalidOtpText());
	    assertEquals(register.invalidOtpText(), string);
	}
}
