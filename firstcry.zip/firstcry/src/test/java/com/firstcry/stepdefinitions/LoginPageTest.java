package com.firstcry.stepdefinitions;

import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import com.firstcry.pages.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageTest {
	private final WebDriver driver= Hooks.driver;
	public LoginPage login;

	@When("User input {string} as mobile number")
	public void user_input_as_mobile_number(String string) {
		login = new LoginPage(driver);
		login.enterPhoneNumber(string);
	}
	
	@When("User click on continue button")
	public void user_click_on_continue_button() {
		login = new LoginPage(driver);
		login.clickContinueBtn();
	}
	@When("User click submit after entering valid otp manually")
	public void user_click_submit_after_entering_valid_otp_manually() {
		login = new LoginPage(driver);
		login.submitOtp();
	}


	@Then("User logged in successfully")
	public void user_logged_in_successfully() {
		login = new LoginPage(driver);
		assertEquals(login.validLoginVerify(), "My Account");
	}

	@When("User click submit after entering Invalid otp manually")
	public void user_click_submit_after_entering_invalid_otp_manually() {
		login = new LoginPage(driver);
		login.submitOtp();
	}

	@Then("User get {string} as error message for invalid credentials")
	public void user_get_as_error_message_for_invalid_credentials(String string) {
		login = new LoginPage(driver);
		System.out.println(login.invalidLoginText());
		assertEquals(login.invalidLoginText(), string);
	}
	
	@Then("User get {string} as error message for invalid login otp")
	public void user_get_as_error_message_for_invalid_login_otp(String string) {
		login = new LoginPage(driver);
		System.out.println(login.invalidOTPText());
		assertEquals(login.invalidOTPText(), string);
	}

}
