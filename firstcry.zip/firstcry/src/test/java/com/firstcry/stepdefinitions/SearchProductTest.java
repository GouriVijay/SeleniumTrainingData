package com.firstcry.stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.ProductPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchProductTest {
	private final WebDriver driver= Hooks.driver;


	@When("User click on search bar")
	public void user_click_on_search_bar() {
	    HomePage home=new HomePage(driver);
	    home.searchBar();
	}

	@When("User enter {string} in search bar and click on search icon")
	public void user_enter_in_search_bar_and_click_on_search_icon(String string) {
		HomePage home=new HomePage(driver);
		home.searchProduct(string);
	}

	@Then("User verify whether user is on the page that displays gear products")
	public void user_verify_whether_user_is_on_the_page_that_displays_gear_products() {
		assertEquals(driver.getTitle(),"Baby Gear Online India - Buy Baby Gear Products at FirstCry.com");
	}

	@Then("User verify whether user is on the page that displays puma products")
	public void user_verify_whether_user_is_on_the_page_that_displays_puma_products() {
		ProductPage product=new ProductPage(driver);
		assertEquals(product.verifyValidSearchResult(), "PUMA Products");
	}

	@Then("User verify whether error message is displayed for invalid items")
	public void user_verify_whether_error_message_is_displayed_for_invalid_items() {
		ProductPage product=new ProductPage(driver);
		String s=product.verifyInvalidSearchResult();
	    assertTrue(s.contains(" did not match any products"));
	}

}
