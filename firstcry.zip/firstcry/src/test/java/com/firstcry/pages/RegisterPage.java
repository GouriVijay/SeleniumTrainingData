package com.firstcry.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.firstcry.base.ReusableMethods;

public class RegisterPage {
    public WebDriver driver;
    
    // Constructor to initialize WebDriver and page elements
    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
	// Web elements definition using @FindBy annotation to locate elements by different strategies
    @FindBy(linkText = "Register Here")
    WebElement register;
    
    @FindBy(name = "usrname")
    WebElement username;
    
    @FindBy(name = "usremail")
    WebElement usermail;
    
    @FindBy(id = "usrmb")
    WebElement usermb;
    
    @FindBy(id = "continueid")
    WebElement getOtp;
    
    @FindBy(css = "div#finalsbtbtn")
    WebElement submitBtn;
    
    @FindBy(xpath = "//div[@class='signuprevamp_verifyOtp_digits_block']/p[2]")
    WebElement OtpText;
    
    @FindBy(xpath = "//div[@class='signuprevamp_form_section']/p[1]")
    WebElement MailText;
    
    // Click on Register Here button
    public void clickRegisterHere() {
        register.click();
    }
    
    // Enter user details (username, email, phone number)
    public void enterDetails(String uname, String mail, String phno) {
        username.sendKeys(uname);
        usermail.sendKeys(mail);
        usermb.sendKeys(phno);
        ReusableMethods.delay(1000); // Delay for 1 second
    }
    
    // Click on get OTP button
    public void clickOtp() {
        getOtp.click();
    }
    
    // Validate OTP
    public void validateOtp() {
        getOtp.click();
        ReusableMethods.delay(30000); // Delay for 30 seconds to enter OTP
        submitBtn.click();
        ReusableMethods.delay(1000);
    }
    
    // return validation text for invalid OTP
    public String invalidOtpText() {
        return OtpText.getText();
    }
    
    // return validation text for invalid email
    public String invalidMailText() {
        return MailText.getText();
    }
}