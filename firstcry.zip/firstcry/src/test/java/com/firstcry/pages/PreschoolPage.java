package com.firstcry.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.firstcry.base.ReusableMethods;

public class PreschoolPage {
    public static WebDriver driver;
    
    // Constructor to initialize WebDriver and page elements
    public PreschoolPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
 // Web elements definition using @FindBy annotation to locate elements by different strategies
    @FindBy(xpath = "//a[@id='school-finder-btn']")
    WebElement preschoolLocatorBtn;
    
    @FindBy(id = "city")
    WebElement city;
    
    @FindBy(xpath = "//select[@id='city']/option[@value='Trivandrum']")
    WebElement Tvm;
    
    @FindBy(css = "input[name='findersubmit']")
    WebElement submitCity;
    
    @FindBy(xpath = "(//div[@class='main-title'])[1]/h1")
    WebElement verifyPreschoolsText;
    
    // Click on the preschool locator button
    public void clickPreschoolLocator() {
        preschoolLocatorBtn.click();
    }
    
    // Select the city Trivandrum
    public void selectCity() {
        city.click();
        Tvm.click();
        submitCity.click();
        ReusableMethods.delay(1000); // Delay for 1 second
    }
    
    // Verify if preschools are present in the selected city
    public String verifyPreschoolCity() {
        return verifyPreschoolsText.getText();
    }
}