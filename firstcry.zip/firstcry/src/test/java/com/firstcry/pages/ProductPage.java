package com.firstcry.pages;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.firstcry.base.ReusableMethods;
 
public class ProductPage {
	public WebDriver driver;
 
	// Constructor to initialize WebDriver and page elements
	public ProductPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
 
	}
 
	// Web elements definition using @FindBy annotation to locate elements by different strategies
	@FindBy(xpath = "//div[@class='titleleft']//h1")
	WebElement pumaTitle;
 
	@FindBy(xpath = "//div[@class='ur_srch_title']/p")
	WebElement noSuchProduct;
 
	@FindBy(xpath = "(//div[@class=\"list_img wifi\"])[1]/a")
	WebElement product;
 
	@FindBy(xpath = "(//span[@class=\"step1 M16_white\"])[1]/span")
	WebElement addProductToCart;
 
	@FindBy(xpath = "//div[@class=\"titleleft\"]/h1")
	WebElement verifybabyBathToys;
 
	@FindBy(css = "div.sort-select")
	WebElement sort;
 
	@FindBy(xpath = "//div[@id='flttp13']")
	WebElement occation;
 
	@FindBy(xpath = "//div[@id='flttp13']/div[2]/div[2]/ul/li[3]/a/span")
	WebElement filter;
 
	@FindBy(linkText = "Discount")
	WebElement discount;
 
	@FindBy(xpath = "(//div[@class=\"li_inner_block\"])[1]")
	WebElement product1;
 
	@FindBy(xpath = "(//div[@class=\"li_inner_block\"])[2]")
	WebElement product2;
 
	@FindBy(className = "menu-container")
	WebElement menuBar;
	
	@FindBy(id = "shortlist")
	WebElement addP1ToShortlist;
 
	// Returns the text of the product title for validation of correct search result
    public String verifyValidSearchResult() {
        return pumaTitle.getText();
    }

    // Returns the text displayed when no matching products are found
    public String verifyInvalidSearchResult() {
        return noSuchProduct.getText();
    }

    // Clicks on the product to view it in detail in a new window
    public void viewProduct() {
        product.click();
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToNextWindow();
        ReusableMethods.delay(1000);
    }

    // Clicks on the product
    public void clickProduct() {
        product.click();
        ReusableMethods.delay(1000);
    }

    // Adds the product to the shopping cart 
    public void addToCart() {
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToNextWindow();
        addProductToCart.click();
        ReusableMethods.delay(1000);
    }

    // Scrolls to the menu bar on the product page
    public void scrollToMenu() {
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.scrollToElement(menuBar);
    }

    // Adds the product directly to the cart from the product listing page
    public void addProductToCart() {
        product.click();
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToNextWindow();
        addProductToCart.click();
        ReusableMethods.delay(1000);
    }

    // Verifies the category text is correct for baby bath toys
    public String verifyBathToys() {
        return verifybabyBathToys.getText();
    }

    // Filters the product listings by discount via the sort dropdown
    public void sortByDiscount() {
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.mouseHover(sort);
        discount.click();
        ReusableMethods.delay(1000);
    }

    // Filters products by a specific occasion using the occasion filter
    public void FilterByOccasion() {
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.scrollToElement(occation);
        filter.click();
        ReusableMethods.delay(1000);
    }

    // Adds the first product to the shopping cart
    public void addProduct1ToCart() {
        product1.click();
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToNextWindow();
        addProductToCart.click();
        reusableMethods.switchToPreviousWindow();
        ReusableMethods.delay(1000);
    }

    // Adds the second product to the shopping cart
    public void addProduct2ToCart() {
        product2.click();
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToParticularWindow(2);
        addProductToCart.click();
        ReusableMethods.delay(1000);
    }

    // Adds a product to the shortlist 
    public void addProductToShortlist() {
        product.click();
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.switchToNextWindow();
        addP1ToShortlist.click();
        ReusableMethods.delay(1000);
    }
 
}