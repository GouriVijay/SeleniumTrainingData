package com.firstcry.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.firstcry.base.ReusableMethods;

public class MyAccountPage {
	public static WebDriver driver;
	
	// Constructor to initialize the web driver and page elements
	public MyAccountPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	// Web elements definition using @FindBy annotation to locate elements by different strategies
	@FindBy(xpath = "//div[@class='lft_ctr lft']/ul[3]/li[4]/a")
	WebElement myAddressBook;
	
	@FindBy(xpath = "//div[@class='sb_head lft wt inv_cre']/a")
	WebElement invitesAndCredits;
	
	@FindBy(id = "txtAddName")
	WebElement name;
	
	@FindBy(id = "txtAddAddress1")
	WebElement Address1;
	
	@FindBy(id = "txtAddAddress2")
	WebElement Address2;
	
	@FindBy(id = "txtAddPincode")
	WebElement pincode;
	
	@FindBy(id = "txtAddcity")
	WebElement cityName;
	
	@FindBy(id = "txtAddState")
	WebElement stateName;
	
	@FindBy(id = "txtAddMobile")
	WebElement phno;
	
	@FindBy(id = "btnSaveAddress")
	WebElement saveAddressBtn;
	
	@FindBy(id = "contact_list")
	WebElement inviteMailId;
	
	@FindBy(xpath = "//span[@class='madd mtit']")
	WebElement defaultAddressText;
	
	@FindBy(xpath = "//div[@class='fw new']/a")
	WebElement addNewAddress;
	
	@FindBy(xpath = "//div[@class='p_right btn1']/span")
	WebElement sendInviteBtn;
	
	@FindBy(xpath = "//div[@class='lft_ctr lft']/ul[5]/li[2]/a")
	WebElement myShortlist;
	
	@FindBy(xpath = "//div[@class='li_txt1 lft wifi']/a")
	WebElement productInShortlist;
	
	@FindBy(className = "prd_delete")
	WebElement deleteProduct;
	
	@FindBy(xpath = "//div[@id='DivErrorMsg']/span")
	WebElement deleteText;
	
	@FindBy(xpath = "//span[@title='Delete']")
	WebElement deleteAddress;
	
	@FindBy(id = "confirmSubmit")
	WebElement confirmAddressDelete;
	
	// Method to navigate to the Address Book section
    public void clickMyAddressBook() {
        myAddressBook.click();
        ReusableMethods.delay(1000);  // Wait for page response
    }

    // Method to fill out address details and save
    public void enterAdressBookData() {
        name.sendKeys("Gayathri Manohar");
        Address1.sendKeys("UST Trivandrum");
        Address2.sendKeys("Trivandrum");
        pincode.sendKeys("690504");
        cityName.sendKeys("Trivandrum");
        stateName.sendKeys("Kerala");
        phno.sendKeys("7306221364");
        ReusableMethods.delay(1000); 
        saveAddressBtn.click();
    }

    // Method to validate and retrieve the default address text
    public String validateDefaultAddress() {
        ReusableMethods.delay(1500); // Wait for the text to update
        return defaultAddressText.getText();
    }

    // Method to navigate to the Invites and Credits section
    public void clickInvitesAndCredits() {
        invitesAndCredits.click();
    }

    // Method to send an invite by entering an email and clicking send
    public void sendInvite() {
        inviteMailId.sendKeys("ancysabu2001@gmail.com");
        sendInviteBtn.click();
    }

    // Method to navigate to the My Shortlist section
    public void clickMyShortlist() {
        myShortlist.click();
    }

    // Method to retrieve the name of a product from the shortlist
    public String getProductNameInShortlist() {
        return productInShortlist.getText();
    }

    // Method to remove a product from the wishlist
    public void removeProductFromWishlist() {
        deleteProduct.click();
    }

    // Method to verify that a product was successfully removed from the wishlist
    public String verifyDeletionFromShortlist() {
        ReusableMethods.delay(1000);
        return deleteText.getText();
    }

    // Method to delete the current address and confirm the deletion
    public void deleteCurrentAddress() {
        deleteAddress.click();
        ReusableMethods.delay(1000);
        confirmAddressDelete.click();
    }

}
