package com.firstcry.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.firstcry.base.ReusableMethods;
public class HomePage {

	// Constructor to initialize WebDriver and page elements
	public WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	// Web elements definition using @FindBy annotation to locate elements by different strategies
	@FindBy(xpath = "//div[@class='fc_login']/ul/li[7]/span[2]")
	WebElement register;

	@FindBy(xpath = "//div[@class='fc_login']/ul/li[7]/span[1]")
	WebElement login;

	@FindBy(xpath = "//div[@class='fc_logo lft']/a")
	WebElement home;

	@FindBy(xpath = "//div[@class='fc_login']/ul/li[8]")
	WebElement myAccount;

	@FindBy(xpath = "/html/body/div[1]/div[5]/div/div[3]/ul/li[8]/span[2]/ul/li[1]/a")
	WebElement myProfile;

	@FindBy(xpath = "//div[@class=\"fc_login\"]/ul/li[8]/span[2]/ul/li[17]/span")
	WebElement logout;

	@FindBy(xpath = "//form[@class=\"headSearchBox\"]/input")
	WebElement searchBox;

	@FindBy(className = "search-button")
	WebElement searchIcon;

	@FindBy(linkText = "ALL CATEGORIES")
	WebElement allCategories;

	@FindBy(linkText = "T-shirts")
	WebElement tshirt;

	@FindBy(linkText = "Baby Names")
	WebElement babyNames;

	@FindBy(xpath = "//div[@class=\"menu-container\"]/ul/li[5]/a")
	WebElement toys;

	@FindBy(linkText = "Bath Toys")
	WebElement bathToys;

	@FindBy(xpath = "//div[@class='btin_srtp']/ul/li[2]")
	WebElement recentlyViewed;

	@FindBy(xpath = "(//div[@class='lft sel_all fw'])[2]/span/input")
	WebElement selectAllInRecent;

	@FindBy(xpath = "(//div[@class='adtocart fw lft'])[2]/div[2]")
	WebElement addProductFromRecent;

	@FindBy(xpath = "(//a[@class='R12_61'])[8]")
	WebElement more;

	@FindBy(xpath = "//div[@class='fc_login']/ul/li[6]/span/ul/li[2]/a")
	WebElement findPreschools;

	@FindBy(xpath = "//div[@class='fc_login']/ul/li[7]/span[1]")
	WebElement verifyRegisterText;

	// Click login or register button
	public void clickloginOrRegister() {
		login.click();
		ReusableMethods.delay(1000); // Delay for 1 second
	}
	
	// View my account
	public void viewMyAccount() {
		ReusableMethods reusableMethods = new ReusableMethods(driver);
		reusableMethods.mouseHover(myAccount);
		ReusableMethods.delay(1000); // Delay for 1 second
	}
	
	// Click logout
	public void clickLogout() {
		logout.click();
	}
	
	// Navigate back to home page
	public void backHome() {
		ReusableMethods.delay(2000); // Delay for 2 seconds
		home.click();
	}
	
	// Click on My Account
	public void clickMyAccount() {
		myAccount.click();
	}
	
	// Clear search bar
	public void searchBar() {
		searchBox.clear();
	}
	
	// Search for a product
	public void searchProduct(String s) {
		searchBox.clear();
		searchBox.sendKeys(s);
		searchIcon.click();
	}
	
	// Search for a brand
	public void searchBrand(String s) {
		searchBox.clear();
		searchBox.sendKeys(s);
		searchIcon.click();
	}
	
	// view add categories section
	public void viewAddCategories() {
		ReusableMethods reusableMethods = new ReusableMethods(driver);
		reusableMethods.mouseHover(allCategories);
	}
	
	// Select a product
	public void selectProduct() {
		tshirt.click();
		ReusableMethods.delay(1000); // Delay for 1 second
	}
	
	// view toys section
	public void viewToys() {
		ReusableMethods reusableMethods = new ReusableMethods(driver);
		reusableMethods.mouseHover(toys);
	}
	
	// Click on Bath Toys
	public void clickBathToys() {
		bathToys.click();
	}
	
	// Click on Recently Viewed
	public void clickRecentlyViewed() {
		recentlyViewed.click();
		ReusableMethods.delay(1000);
	}
	
	// Add product to cart
	public void addProductToCart() {
		selectAllInRecent.click();
		addProductFromRecent.click();
	}
	
	// Navigate to My Profile within My Account
	public void navigateToMyAccount() {
		ReusableMethods.delay(1000);
		myProfile.click();
	}
	
	// Verify successful registration and return text
	public String verifySuccessfulRegistration() {
		return verifyRegisterText.getText();
	}
	
	// Click on Find Preschools
	public void clickFindPreschools() {
		ReusableMethods reusableMethods = new ReusableMethods(driver);
		reusableMethods.mouseHover(more);
		findPreschools.click();
		reusableMethods.switchToNextWindow(); // Switch to the next window/tab
	}
}