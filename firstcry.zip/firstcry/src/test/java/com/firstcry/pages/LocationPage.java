package com.firstcry.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LocationPage {
    public WebDriver driver;
    
    // Constructor to initialize WebDriver and page elements
    public LocationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
	// Web elements definition using @FindBy annotation to locate elements by different strategies
    @FindBy(xpath = "//div[@class='loctio-div']")
    WebElement selectLocation;
    
    @FindBy(xpath = "//sapn[@class='R14_link']")
    WebElement clickPincode;
    
    @FindBy(id = "nonlpincode")
    WebElement pincode;
    
    @FindBy(xpath = "(//div[@class='appl-but'])[1]")
    WebElement apply;
    
    @FindBy(xpath = "(//span[@class='error-mesg R12_red non-blk geoerr'])[1]")
    WebElement locationError;
    
    @FindBy(id = "geopincode")
    WebElement displayedPincode;
    
    // Click on the select location
    public void clickSelectLocation() {
        selectLocation.click();
    }
    
    // Enter pincode and click on apply
    public void enterPincode(String pin) {
        clickPincode.click();
        pincode.clear();
        pincode.sendKeys(pin);
        apply.click();
    }
    
    // Get invalid location error message and return it
    public String invalidLocationText() {
        return locationError.getText();
    }
     
    // Get displayed pincode
    public String showDisplayedPincode() {
        return displayedPincode.getText();
    }
}