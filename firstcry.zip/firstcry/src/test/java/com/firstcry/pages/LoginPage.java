package com.firstcry.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.firstcry.base.ReusableMethods;

public class LoginPage {
    public static WebDriver driver;
    
    // Constructor to initialize WebDriver and page elements
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
 // Web elements definition using @FindBy annotation to locate elements by different strategies
    @FindBy(id = "lemail")
    WebElement phno;
    
    @FindBy(xpath = "//span[@class='J14SB_42 cl_fff']")
    WebElement continueBtn;
    
    @FindBy(xpath = "(//span[@class=\"J14SB_42 cl_fff\"])[2]")
    WebElement submitBtn;
    
    @FindBy(xpath = "//div[@class='loginSignup_form_section div_input']/p")
    WebElement LoginText;
    
    @FindBy(xpath = "//div[@class='loginSignup_verifyOtp_popup_details div_input']/p[4]")
    WebElement OtpText;
    
    @FindBy(xpath = "//span[@class='anch myacc_2']")
    WebElement verifyLogin;
    
    // Enter phone number in the login field
    public void enterPhoneNumber(String mobNo) {
        phno.sendKeys(mobNo);
    }
    
    // Click on the continue button
    public void clickContinueBtn() {
        ReusableMethods.delay(1000); // Delay for 1 second
        continueBtn.click();
    }
    
    // Submit OTP
    public void submitOtp() {
        ReusableMethods.delay(30000); // Delay for 30 seconds for entering OTP
        submitBtn.click();
    }
    
    // Get text for invalid login
    public String invalidLoginText() {
        ReusableMethods.delay(1000);
        return LoginText.getText();
    }
    
    // Get text for invalid OTP
    public String invalidOTPText() {
        return OtpText.getText();
    }
    
    // Get text for successful login verification
    public String validLoginVerify() {
        return verifyLogin.getText();
    }
    
    // Enter login details aand submit OTP
    public void enterLoginDetails() {
        phno.sendKeys("9633187161");
        ReusableMethods.delay(1000);
        continueBtn.click(); //
        ReusableMethods.delay(30000); // Delay for 30 seconds for entering OTP
        submitBtn.click();
    }
}