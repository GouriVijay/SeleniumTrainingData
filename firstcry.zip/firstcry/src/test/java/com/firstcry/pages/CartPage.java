package com.firstcry.pages;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.firstcry.base.ReusableMethods;

public class CartPage {
	public WebDriver driver;
	
	// Constructor to initialize the web driver and page elements
	public CartPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	// Web elements definition using @FindBy annotation to locate elements by different strategies
	@FindBy(className = "loginregister")
	WebElement login;
	
	@FindBy(xpath = "//span[@class=\"M14_61 pos-rel\"]")
	WebElement cartIcon;
	
	@FindBy(xpath="(//span[@class=\"step1 M16_white\"])[1]/span]")
	WebElement goToCart;
	
	@FindBy(xpath = "(//span[@class=\"M14_61 pos-rel\"]//span)[1]")
	WebElement noOfProductsinCart;
	
	@FindBy(xpath="//div[@id=\"productlist\"]")
	List<WebElement> ValidProducts;
	
	@FindBy(xpath = "//div[@id='productlist']/div[1]")
	WebElement move;
	
	@FindBy(xpath = "(//div[@class=\"new-shortone shortcomm\"])[1]")
	WebElement removeProduct;
	
	@FindBy(xpath = "//div[@class='empty-cart-info']/h4")
	WebElement emptyCart;
	
	@FindBy(xpath = "//div[@id='selectqnty']")
	WebElement quantity;
	
	@FindBy(className = "showpayment_popup")
	WebElement placeOrder;
	
	@FindBy(xpath = "//div[@id='CodTab']")
	WebElement cod;
	
	@FindBy(xpath="(//div[@class='cod-ordersbtn J14SB_42 cl_fff btn PreCOD btn_comm btn_outline'])")
	WebElement placeCOD;
	
	// Method to click on the login button
    public void clickLogin() {
        login.click();
    }

    // Method to click on the cart icon
    public void clickCartIcon() {
        cartIcon.click();
        ReusableMethods.delay(1000);
    }

    // Method to navigate to the cart page
    public void clickGoToCart() {
        goToCart.click();
    }

    // Method to get the number of valid products listed in the cart
    public int getNumberOfProductsInCart() {
        return ValidProducts.size();
    }

    // Method to fetch the text that indicates the number of products in the cart
    public String verifyNoOfCartProducts() {
        return noOfProductsinCart.getText();
    }

    // Method to remove the first product from the cart
    public void removeFirstProductFromCart() {
        ReusableMethods reusableMethods = new ReusableMethods(driver);
        reusableMethods.scrollToElement(move);
        removeProduct.click();
        ReusableMethods.delay(2000);
    }

    // Method to remove the second product from the cart
    public void removeSecondProductFromCart() {
        removeProduct.click();
    }

    // Method to verify if the cart is empty by checking the text content
    public String verifyEmptyCart() {
        return emptyCart.getText();
    }

    // Method to select a quantity for a product in the cart
    public void selectQuantity() {
        quantity.click();
    }

    // Method to click on place order icon
    public void clickPlaceOrder() {
        placeOrder.click();
        ReusableMethods.delay(1000);
    }

    // Method to select Cash on Delivery as the payment method
    public void clickCOD() {
        cod.click();
    }

    // Method to return the text from the place Cash on Delivery button
    public String placeCOD() {
    	ReusableMethods reusableMethods= new ReusableMethods(driver);
    	reusableMethods.waitUntilVisible(placeCOD);
        return placeCOD.getText();
    }
}
