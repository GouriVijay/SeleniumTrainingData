package com.firstcry.tests;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.firstcry.base.DriverSetup;
import com.firstcry.base.ReusableMethods;
import com.firstcry.pages.CartPage;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.LoginPage;
import com.firstcry.pages.ProductPage;

@Listeners(com.firstcry.utils.ExtentReportsListener.class)
public class CheckOutTest {
    public static WebDriver driver;
    ReusableMethods reusableMethods;
    
    //Method to set up the WebDriver and open the website before running the tests
    @BeforeClass(groups = "checkout")
    public void setup() {
        driver = DriverSetup.invokeEdge();
        reusableMethods = new ReusableMethods(driver);
        reusableMethods.openWebsite();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    
    //Test method to perform checkout process
    @Test(groups = "checkout")
    public void checkout() {
        //Instantiate page objects
        HomePage home = new HomePage(driver);
        ProductPage product = new ProductPage(driver);
        CartPage cart = new CartPage(driver);
        LoginPage log = new LoginPage(driver);
        
        //Select a product,apply filters and add it to cart
        home.viewAddCategories();
        home.selectProduct();
        ReusableMethods.delay(1000);
        product.FilterByOccasion();
        product.clickProduct();
        product.addToCart();
        
        //Navigate to cart, login, place order, and choose COD
        cart.clickCartIcon();
        cart.clickLogin();
        log.enterLoginDetails();
        cart.clickPlaceOrder();
        cart.clickCOD();
        
        //Verify if the COD place order button is present
        assertTrue(cart.placeCOD().contains("PLACE COD"));
    }
    
 // Method to capture a screenshot of failed test cases
 		@AfterMethod(groups = "checkout")
 		public void captureScreenshotOfFail(ITestResult result) {
 			if (result.getStatus() == ITestResult.FAILURE) {
 				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
 				try {
 					Date d1 = new Date();
 					FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
 				} catch (IOException e) {
 					e.printStackTrace();
 				}
 			}
 		}
}