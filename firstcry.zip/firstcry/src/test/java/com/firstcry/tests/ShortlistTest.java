package com.firstcry.tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.firstcry.base.DriverSetup;
import com.firstcry.base.ReusableMethods;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.LoginPage;
import com.firstcry.pages.MyAccountPage;
import com.firstcry.pages.ProductPage;
import com.firstcry.utils.ExcelHandling;

@Listeners(com.firstcry.utils.ExtentReportsListener.class)
public class ShortlistTest {
	public static WebDriver driver;
	ReusableMethods reusableMethods;
	
    //DataProvider to supply data for tests, fetching product names from Excel
	@DataProvider(name = "ShortlistProduct")
	public String[][] getLoginData() throws IOException {
		String path = "././capstone_exceldata/firstCryData.xlsx";
		String sheet = "productSearch";
		return ExcelHandling.fetchUserDetails(path, sheet);
	}
	
    //Setup method executed before each test method in groups "addShortlist" and "removeShortlist"
	@BeforeMethod(groups = {"addShortlist", "removeShortlist"})
	public void setup() {
		driver = DriverSetup.invokeEdge();  
		reusableMethods = new ReusableMethods(driver);  
		reusableMethods.openWebsite();  
		
        //perform login
		HomePage home = new HomePage(driver);
		LoginPage log = new LoginPage(driver);
		home.clickloginOrRegister();
		log.enterPhoneNumber("9400775516");
		log.clickContinueBtn();
		log.submitOtp();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

    //Test method to add an item to the shortlist
	@Test(dataProvider = "ShortlistProduct", groups = "addShortlist")
	public void addItemToShortlistTest(String productName) {
		HomePage home = new HomePage(driver);
		home.searchProduct(productName);  // Search for the product
		ProductPage p1 = new ProductPage(driver);
		p1.addProductToShortlist();  // Add product to shortlist
		
        //Navigate to My Account and verify the product is shortlisted
		home.viewMyAccount();
		home.navigateToMyAccount();
		MyAccountPage myAccount = new MyAccountPage(driver);
		myAccount.clickMyShortlist();
		assertEquals(myAccount.getProductNameInShortlist(), "10,000 Selected Baby Names Book - English");
	}
	
    //Test method to remove an item from the shortlist
	@Test(groups = "removeShortlist")
	public void removeItemFromShortlist() {
		HomePage home = new HomePage(driver);
		home.viewMyAccount();
		home.navigateToMyAccount();
		MyAccountPage myAccount = new MyAccountPage(driver);
		myAccount.clickMyShortlist();
		myAccount.removeProductFromWishlist();  //Remove the product from shortlist
		
        //Handle alert and validate if shortlist is empty
		ReusableMethods reusable = new ReusableMethods(driver);
		reusable.acceptAlert();
		assertEquals(myAccount.verifyDeletionFromShortlist(), "You have not shortlisted any product yet");
	}	
	
	// Method to capture a screenshot of failed test cases
	 		@AfterMethod(groups = {"addShortlist", "removeShortlist"})
	 		public void captureScreenshotOfFail(ITestResult result) {
	 			if (result.getStatus() == ITestResult.FAILURE) {
	 				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	 				try {
	 					Date d1 = new Date();
	 					FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
	 				} catch (IOException e) {
	 					e.printStackTrace();
	 				}
	 			}
	 		}
}
