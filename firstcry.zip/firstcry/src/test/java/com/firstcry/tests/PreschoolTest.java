package com.firstcry.tests;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.firstcry.base.DriverSetup;
import com.firstcry.base.ReusableMethods;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.LoginPage;
import com.firstcry.pages.PreschoolPage;
import com.firstcry.utils.ExcelHandling;
@Listeners(com.firstcry.utils.ExtentReportsListener.class)
public class PreschoolTest {
    public static WebDriver driver;
    ReusableMethods reusableMethods;
    
    //DataProvider method to provide login data from an Excel sheet
    @DataProvider(name = "LoginData")
    public String[][] getLoginData() throws IOException {
        String path = "././capstone_exceldata/firstCryData.xlsx";
        String sheet = "loginData";
        return ExcelHandling.fetchUserDetails(path, sheet);
    }
    
    //Method to set up the WebDriver and open the web site before running the tests
    @BeforeClass(groups = "preschool")
    public void setup() {
        driver = DriverSetup.invokeEdge();
        reusableMethods = new ReusableMethods(driver);
        reusableMethods.openWebsite();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    
    //Test method to find preschools in a particular city
    @Test(dataProvider = "LoginData", groups = "preschool")
    public void findPreschoolsTest(String phno) {
        //Instantiate page objects
        HomePage home = new HomePage(driver);
        LoginPage log = new LoginPage(driver);
        
        //Perform login
        home.clickloginOrRegister();
        log.enterPhoneNumber(phno);
        log.clickContinueBtn();
        log.submitOtp();
        
        //Click on find pre-schools and verify the city
        home.clickFindPreschools();
        PreschoolPage preschool = new PreschoolPage(driver);
        preschool.clickPreschoolLocator();
        
        //select city as Trivandrum
        preschool.selectCity();
        //verify if the search results contain pre-school in Trivandrum
        assertEquals(preschool.verifyPreschoolCity(), "FirstCry Intellitots Preschools In Trivandrum");
    }
    
 // Method to capture a screenshot of failed test cases
		@AfterMethod(groups = "preschool")
		public void captureScreenshotOfFail(ITestResult result) {
			if (result.getStatus() == ITestResult.FAILURE) {
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				try {
					Date d1 = new Date();
					FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
}