package com.firstcry.tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.firstcry.base.DriverSetup;
import com.firstcry.base.ReusableMethods;
import com.firstcry.pages.CartPage;
import com.firstcry.pages.HomePage;
import com.firstcry.pages.ProductPage;
import com.firstcry.utils.ExcelHandling;

//Listener for generating Extent Reports for test execution tracking
@Listeners(com.firstcry.utils.ExtentReportsListener.class)
public class AddToCartTest {
	public static WebDriver driver;
	ReusableMethods reusableMethods;

	// Setup method to initialize WebDriver and ReusableMethods object
	@BeforeClass(groups= {"add","addRecent"})
	public void setup() {
		driver = DriverSetup.invokeEdge();  
		reusableMethods = new ReusableMethods(driver); 
	}

	// Method to open website and set implicit wait before each test method
	@BeforeMethod(groups= {"add","addRecent"})
	public void before() {
		reusableMethods.openWebsite();  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); 
	}

	// Test method to add an item to the cart and assert the cart count
	@Test(groups="add",priority=1)
	public void addItemToCart() {
		 //Instantiate page objects
		HomePage home = new HomePage(driver);
		ProductPage product = new ProductPage(driver);
		CartPage cart = new CartPage(driver);
		
		//View addCategories , select a product and add it to cart 
		home.viewAddCategories();         
		home.selectProduct();             
		product.addProductToCart(); 
		
		// Click on cart icon
		cart.clickCartIcon();             
		assertEquals(cart.getNumberOfProductsInCart(), 1); // Assert that the cart contains added item
	}

	// DataProvider for test data
	@DataProvider(name="productToSearch")
	public String[][] getLoginData() throws IOException {
		String path = "././capstone_exceldata/firstCryData.xlsx";
		String sheet = "productCategory";
		return ExcelHandling.fetchUserDetails(path, sheet); // Fetch data from Excel sheet
	}

	// Test method to add item from recently viewed products using data provided by DataProvider
	@Test(dataProvider = "productToSearch", groups="addRecent",priority=2)
	public void addItemFromRecentlyViewed(String productCategory) {
		HomePage home = new HomePage(driver);
		ProductPage product = new ProductPage(driver);
		CartPage cart = new CartPage(driver);
		
		//Search product in search bar and view the product
		home.searchProduct(productCategory);  
		product.viewProduct();               
		ReusableMethods.delay(1000);     
		
		//Navigate back to home, click on 'Recently Viewed' products and all the recently viewed products to cart
		home.backHome();                     
		home.clickRecentlyViewed();          
		home.addProductToCart(); 
		
		//click on cart icon
		cart.clickCartIcon();                
		assertEquals(cart.getNumberOfProductsInCart(), 1); // Assert that the cart contains exactly 1 item
	}

	// Method to capture a screenshot of failed test cases
		@AfterMethod(groups= {"add","addRecent"})
		public void captureScreenshotOfFail(ITestResult result) {
			if (result.getStatus() == ITestResult.FAILURE) {
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				try {
					Date d1 = new Date();
					FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

}
