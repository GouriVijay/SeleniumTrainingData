package com.firstcry.base;
 
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.firstcry.utils.PropertyFile;
 
public class ReusableMethods {
	public static WebDriver driver;
	public static Properties properties;
 
	public ReusableMethods(WebDriver driver) {
		this.driver=driver;
		properties=PropertyFile.getProperties();
	}
 
	//method to invoke web browser
	public static WebDriver invokeBrowser() {
		properties=PropertyFile.getProperties();
		try {
			String browserChoice=properties.getProperty("browser1");
			if(browserChoice.equalsIgnoreCase("edge"))
				driver=DriverSetup.invokeEdge();
			else if (browserChoice.equalsIgnoreCase("chrome")) {
				driver = DriverSetup.invokeChrome();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return driver;
	}
 
    //method to open website
	public void openWebsite() {
		driver.get(properties.getProperty("url"));
	}
 
	//method to apply delay for few seconds
	public static void delay(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	//method to scroll until a particular element
		public void scrollToElement(final WebElement element) {
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",element);
		}
		
	//method to hover over an element
	public void mouseHover(final WebElement element) {
        final Actions action = new Actions(driver);
        action.moveToElement(element).build().perform();
        delay(3);
    }
	//method to switch to next window
	public void switchToNextWindow() {
		driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
	}
	//method to switch to previous window
 
	public void switchToPreviousWindow() {
		driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
	}
	//method to switch to particular window
 
	public void switchToParticularWindow(int num) {
		driver.switchTo().window(driver.getWindowHandles().toArray()[num].toString());
	}
	//method used to accept alert
	public void acceptAlert() {
		Alert a=driver.switchTo().alert();
		a.accept();
	}
	public void waitUntilVisible(WebElement element)
	{	
		//explicitly wait until visibility of web element
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
 
}
