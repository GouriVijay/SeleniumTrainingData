package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	public static WebDriver driver;

	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	//xpath for searchIcon
	@FindBy(xpath = "//div[@class='header__right']/search-modal/details/summary/span")
	WebElement searchIcon;
	
	//xpath for searchbar
	@FindBy(xpath = "//div[@class=\"field has-recommendation\"]/button[1]")
	WebElement searchBar;
	
	//css selector for cart icon
	@FindBy(css = "div.header__right > cart-drawer")
	WebElement cartIcon;
	
	
	//methord to search a product
	public void searchProduct(String s)
	{
		searchIcon.click();
		searchBar.sendKeys(s);
		searchBar.click();
	}
	
	//method to click cart icon
	public void clickCartIcon() {
		cartIcon.click();
	}
	

/*         cucumber methods           */
	
	//method to click on search icon
	public void clickSearchIcon() {
		searchIcon.click();
	}
	
	//method to enter search product and search
	public void enterProductToSearch(String s)
	{
		searchBar.sendKeys(s);
		searchBar.click();
	}
	


}
