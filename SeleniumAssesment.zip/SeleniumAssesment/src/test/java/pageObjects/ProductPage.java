package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPage {
	public static WebDriver driver;
	
	public ProductPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	//xpath to click product
	@FindBy(xpath = "(//div[@class='card-wrapper'])[1]")
	WebElement clickProduct;
	
	//css to get product text
	@FindBy(css =  "div.product__title>div>div.product__text")
	WebElement productText;
	
	
	//xpath to choose size
	@FindBy(xpath = "//div[@class='main-product_variants']/variant-radios/fieldset/label[2]")
	WebElement size;
	
	//xpath to click add to cart
	@FindBy(xpath = "(//div[@class='product-form__buttons']/button)[1]")
	WebElement addToCart;
	
	//locator for cartIcon
	@FindBy(xpath = "//div[@class='header__right']/cart-drawer/details/summary/span/span[@class='cart-count-bubble']/span[2]")
	WebElement numInCartIcon;

	//xpath to verify shown product
	@FindBy(xpath = "(//div[@class='product-count'])[2]/p")
	WebElement productShown;
	
	//xpath to verify invalid search
	@FindBy(xpath = "//div[@class=\"title-wrapper center\"]/p")
	WebElement noResult;
	
	
	//method to view product
	public void viewProduct() {
		clickProduct.click();		
	}
	
	//method to verify product name
	public String verifyProductName() {
		return productText.getText();
	}
	
	//method to add product to cart
	public void addProductToCart() {
		size.click();
		addToCart.click();
	}
	
	//method that returns number of products in cart
	public String numInCartIcon() {
		return numInCartIcon.getText();
	}
	
	//method that return search result 
	public String validSearchResult() {
		return productShown.getText();
	}
	
	//method that returns no result found text
	public String InvalidsearchResult() {
		String[] s= noResult.getText().split(" for");
		String result=s[0];
		return result;
	}
	
	
	
}
