package UST.Assignment1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.Test;

public class BrowserConfiguration {
	@Test
	public static WebDriver Setup() {
		//WebDriver driver=new EdgeDriver();
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable--notifications");
//		EdgeOptions eoptions = new EdgeOptions();
//		eoptions.addArguments("--guest");

		options.addArguments("--start-maximized");
		
		//maximize DRiver
//		driver.manage().window().maximize();
		WebDriver driver=new ChromeDriver(options);
		return driver;
	}
}