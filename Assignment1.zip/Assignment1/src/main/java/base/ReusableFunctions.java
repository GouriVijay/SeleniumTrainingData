package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.FileIO;

public class ReusableFunctions {

	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties properties;
	public static String browser_choice;
	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		properties = FileIO.getProperties();
	}
	/*********Report fail Test**********/
	public static void reportFail(String message) {
		Assert.fail("Testcase Failed: "+message);
	}
	public static WebDriver invokeBrowser() {
		if(properties==null)
			properties=FileIO.getProperties();
		browser_choice = properties.getProperty("browser");
		try {
			if (browser_choice.equalsIgnoreCase("chrome")) {
				driver = DriverSetup.invokeChromeBrowser();
			} else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		return driver;
	}

	/**********open website*********/
	public void openWebsite(String url) {
		try {
			driver.get(properties.getProperty(url));
		}catch(Exception e) {
			reportFail(e.getMessage());
		}
	}

	/**********Get by locator using locator key*********/
	public static By getLocator(String locatorKey) {
		if(locatorKey.endsWith("_id")) {
			return By.id(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_name")) {
			return By.name(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_xpath")) {
			return By.xpath(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_css")) {
			return By.cssSelector(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_class")) {
			return By.className(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_tag")) {
			return By.tagName(properties.getProperty(locatorKey));
		}
		if(locatorKey.endsWith("_linkText")) {
			return By.linkText(properties.getProperty(locatorKey));
		}
		reportFail("Invalid locator key provided"+locatorKey);
		return null;
	}
	/**********wait for the element to display on the page*********/
	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	/**********set text to any input field*********/
	public void setTextToInputField(WebElement element, String text) {
		waitForElementToDisplay(element);
		element.clear();
		element.sendKeys(text);
	}
	/**********click on any element*********/
	public void clickOnElement(WebElement element) {
		element.click();
	}

}
