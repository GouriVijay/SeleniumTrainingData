package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ebay_pom {
	public static WebDriver driver;

	public ebay_pom(WebDriver driver) {
		this.driver = driver;
	}

	public void openWebsite() {
		try {
			driver.get("http://ebay.com/");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void searchBox() {
		 driver.findElement(By.xpath("//input[@class=\"gh-tb ui-autocomplete-input\"]")).sendKeys("Selenium");
	}
	
	public void selectOption() {
		driver.findElement(By.xpath("//select[@id=\"gh-cat\"]//option[@value=\"267\"]")).click();
	}
	public void searchButton() {
	 driver.findElement(By.xpath("//input[@id='gh-btn']")).click();
	}
	public void buyItNow() {
	 driver.findElement(By.xpath("(//span[@class=\"srp-format-tabs-h2\"])[3]")).click();
	 }
	public void buttonCell() { 
	 driver.findElement(By.xpath("(//span[@class=\"btn__cell\"])[4]")).click();
	}
	public void newlyListed() {
	 driver.findElement(By.xpath("//span[@class=\"fake-menu-button__menu fake-menu-button__menu--reverse\"]//ul[1]//li[3]//a//span")).click();
	}
	public String validate() {
		return driver.findElement(By.xpath("(//span[@class=\"BOLD\"])[3]")).getText(); 
	}
}


















