
package pom;


import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import utilities.FileIO;

public class myntra_pom {

	public static WebDriver driver;
	public static Properties properties = FileIO.getProperties();

	public myntra_pom(WebDriver driver) {
		this.driver = driver;
	}

	
	public void openWebsite() {
		try {
			driver.get(properties.getProperty("testSiteURL1"));
		}catch(Exception e) {
			reportFail(e.getMessage());
		}
	}
	public static void reportFail(String message) {
		Assert.fail("Testcase Failed: "+message);
	}

	
	By search = By.xpath(properties.getProperty("search_xpath"));

	public void enterSearch() {
		driver.findElement(search).sendKeys("Bluetooth headphones");
	}

	By submit = By.cssSelector(properties.getProperty("submit_css"));

	public void clickSubmit() {
		driver.findElement(submit).click();
	}

	By sort = By.className(properties.getProperty("sort_class"));

	public void clicksort() {
		driver.findElement(sort).click();
	}

	By neww = By.xpath(properties.getProperty("new_xpath"));

	public void clickNew() {
		driver.findElement(neww).click();
	}

	By jbl = By.xpath(properties.getProperty("jbl_xpath"));

	public void selectJbl() {
		driver.findElement(jbl).click();
	}

	By strJbl = By.xpath(properties.getProperty("validate_xpath"));

	public String validate() {
		return driver.findElement(strJbl).getText();
	}


}



