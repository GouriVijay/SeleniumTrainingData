package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverSetup;

public class Angular_pom {
	public static WebDriver driver;
	
	@FindBy(linkText = "My Courses")
	WebElement course;
	
	@FindBy(xpath = "(//div[@class='total-lessons'])[1]")
	WebElement clickCourse;
	
	@FindBy(xpath = "//checkbox[1]")
	WebElement check;
	
	
	
	public String getInitialURL() {
		driver = DriverSetup.invokeChromeBrowser();
		driver.get("http://angular-university.io/");
		PageFactory.initElements(driver, this);
		return driver.getCurrentUrl();
	}
	
	public String myCourses() throws InterruptedException {
		course.click();
		Thread.sleep(5000);
		return driver.getCurrentUrl();		
	}
	
	public String angularForBeginners(){
		clickCourse.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver.getCurrentUrl();
	}
	
	public String checkBox1() {
		check.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver.getCurrentUrl();
	}
}
