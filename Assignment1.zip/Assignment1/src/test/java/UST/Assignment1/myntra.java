package UST.Assignment1;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ReusableFunctions;
import pom.myntra_pom;

public class myntra {
	public static WebDriver driver;
	public ReusableFunctions reusableFunctions;
	public myntra_pom myntra; 
	@BeforeClass
	public void beforeTest() {
		driver = ReusableFunctions.invokeBrowser();
		myntra=new  myntra_pom(driver);
	}
	@Test
	public void myntra() throws InterruptedException {
		myntra.openWebsite();
		myntra.enterSearch();
		myntra.clickSubmit();
		myntra.clicksort();
		myntra.clickNew();
		Thread.sleep(1000);
		myntra.selectJbl();
		Thread.sleep(5000);
		System.out.println(myntra.validate());
		assertEquals(true,myntra.validate().equalsIgnoreCase("JBL"));
	}

}


























//         driver.findElement(reusableFunctions.getLocator("SearchBox_class")).sendKeys("Bluetooth headphones");
//         driver.findElement(reusableFunctions.getLocator("Submit_xpath")).click();
//         driver.findElement(reusableFunctions.getLocator("sort_xpath")).click();
//         driver.findElement(reusableFunctions.getLocator("sort1_xpath")).click(); 
//         Thread.sleep(1000);
//         driver.findElement(reusableFunctions.getLocator("jbl_xpath")).click();
//         Thread.sleep(5000);
//         String s=driver.findElement(reusableFunctions.getLocator("validate_xpath")).getText();
//         System.out.println(s);
//         String s1="JBL";
//         String s2="pebble";
//         assertEquals(true, s.equalsIgnoreCase(s1));
//         assertEquals(false, s.equalsIgnoreCase(s2));



