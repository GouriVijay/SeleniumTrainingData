package UST.Assignment1;
import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ReusableFunctions;

public class amazon {
	public static WebDriver driver;
	public ReusableFunctions reusableFunctions;
	@BeforeClass
	public void beforeTest() {
		driver = ReusableFunctions.invokeBrowser();
		reusableFunctions = new ReusableFunctions(driver);
	}
	@Test
	public void myntra() {
		reusableFunctions.openWebsite("testSiteURL2");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 driver.findElement(reusableFunctions.getLocator("todaysDeals_linkText")).click();
		 driver.findElement(reusableFunctions.getLocator("clearance_linkText")).click();
		 driver.findElement(reusableFunctions.getLocator("watches_linkText")).click();
		 driver.findElement(reusableFunctions.getLocator("get_xpath")).click();
		String s= driver.findElement(reusableFunctions.getLocator("Results_xpath")).getText();
		String s1="Results";
		assertEquals(true, s.equals(s1));
		String s2= driver.findElement(reusableFunctions.getLocator("containsWatch_xpath")).getText();
		String s3="Watch";
		assertEquals(true, s2.contains(s3));
		
	
	}

}
