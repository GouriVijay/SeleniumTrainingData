package UST.Assignment1;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import base.ReusableFunctions;
import pom.ebay_pom;
public class Ebay {
	public static WebDriver driver;
	public ebay_pom ebay;
	@BeforeClass
	public void beforeTest() {
		driver=ReusableFunctions.invokeBrowser();
		ebay=new ebay_pom(driver);
	}
	@Test
	public void Ebay() {
		ebay.openWebsite();
		ebay.searchBox();
		ebay.selectOption();
		ebay.searchButton();
		ebay.buyItNow();
		ebay.buttonCell();
		ebay.newlyListed();
		assertEquals(true,ebay.validate().contains("Mar") );
       
	}
}























//	public static WebDriver driver;
//	public ReusableFunctions reusableFunctions;
//	@BeforeClass
//	public void beforeTest() {
//		driver = ReusableFunctions.invokeBrowser();
//		reusableFunctions = new ReusableFunctions(driver);
//	}
//	@Test
//	public void ebay() {
//         reusableFunctions.openWebsite("testSiteURL");
//         driver.findElement(reusableFunctions.getLocator("searchBox_xpath")).sendKeys("Selenium");
//         driver.findElement(By.xpath("//select[@id=\"gh-cat\"]//option[@value=\"267\"]")).click();
//         driver.findElement(By.xpath("//input[@id='gh-btn']")).click();
//         driver.findElement(By.xpath("(//span[@class=\"srp-format-tabs-h2\"])[3]")).click();
//         driver.findElement(By.xpath("(//span[@class=\"btn__cell\"])[4]")).click();
//         driver.findElement(By.xpath("//span[@class=\"fake-menu-button__menu fake-menu-button__menu--reverse\"]//ul[1]//li[3]//a//span")).click();
//       String s1=driver.findElement(By.xpath("(//span[@class=\"BOLD\"])[3]")).getText(); 
//       String s2="Mar";
//       String s3="Sep";
//       assertEquals(false, s1.contains(s3));
//       assertEquals(true, s1.contains(s2));
//         
//
//  
//    }
//	
//	
//}
