package UST.Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ReusableFunctions;


public class RelativeLocator1 {
	public static WebDriver driver;
	@BeforeClass
	public void beforeTest() {
		driver=ReusableFunctions.invokeBrowser();
	}
	
	@Test
	public void google() {
		driver.get("http://www.google.com");
		By search=RelativeLocator.with(By.tagName("textarea")).toRightOf(By.className("CcAdNb"));
		driver.findElement(search).sendKeys("selenium"+Keys.ENTER);
	}
	
	@Test
	public void Ebay() {
		driver.get("http://www.ebay.com");
		By search=RelativeLocator.with(By.tagName("input")).toLeftOf(By.id("gh-cat"));
		driver.findElement(search).sendKeys("samsung");
		By submit=RelativeLocator.with(By.tagName("input")).toRightOf(By.id("gh-cat"));
		driver.findElement(submit).click();
	}
}
