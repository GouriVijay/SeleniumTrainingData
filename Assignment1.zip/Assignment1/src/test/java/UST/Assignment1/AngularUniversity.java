package UST.Assignment1;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pom.Angular_pom;

public class AngularUniversity {
	
	public Angular_pom angular;
	
	@BeforeTest
	public void beforeTest() {
		angular=new Angular_pom();
	}
	@Test(priority = 1)
	public void testInitialURL() {
		String val = angular.getInitialURL();
		assertEquals("https://angular-university.io/", val);
	}
	
	@Test(priority = 2)
	public void testmyCourses() throws InterruptedException {
		String val=angular.myCourses();
		boolean arr=val.contains("my-courses");
		assertTrue(arr);
	}
	
	@Test(priority = 3)
	public void testAngularForBeginners() {
		String val=angular.angularForBeginners();
		boolean arr=val.contains("getting-started-with-angular2");
		assertTrue(arr);
	}

	@Test(priority = 4)
	public void testCheckBox() {
		angular.checkBox1();
	}
	

}
